create table Event_(
	EID int primary key NOT NULL,
    Ename varchar(50),
    location varchar(50),
    type_ varchar(50) check(type_ = 'seminar' or type_ = 'workshop' or type_ = 'conference'),
    start_date date,
    start_time time,
    end_date date,
    end_time time
);

create table Organization_(
	OID int primary key NOT NULL,
    Oname varchar(50),
    address varchar(50)
);

create table Participants(
	PID int primary key NOT NULL,
    Pname varchar(50),
    bdate date,
    gender char(1),
    OID int,
    foreign key (OID) references Organization_(OID) on update cascade on delete set NULL
);

create table Sponsors(
	EID int NOT NULL,
    OID int NOT NULL,
    amount int,
    primary key (EID,OID),
    foreign key (EID) references Event_(EID) on update cascade on delete cascade,
    foreign key (OID) references Organization_(OID) on update cascade on delete cascade
);

create table Attended(
	PID int NOT NULL,
    EID int NOT NULL,
    primary key (EID,PID),
    foreign key (EID) references Event_(EID) on update cascade on delete cascade,
    foreign key (PID) references Participants(PID) on update cascade on delete cascade
);

INSERT INTO Event_ VALUES
(1, 'AI Conference', 'New York', 'conference', '2022-05-01', '09:00:00', '2022-05-03', '18:00:00'),
(2, 'Machine Learning Seminar', 'San Francisco', 'seminar', '2022-06-10', '14:00:00', '2022-06-10', '18:00:00'),
(3, 'Web Development Workshop', 'London', 'workshop', '2022-07-20', '10:00:00', '2022-07-21', '16:00:00'),
(4, 'Data Science Conference', 'Chicago', 'conference', '2022-08-15', '08:00:00', '2022-08-17', '18:00:00'),
(5, 'Artificial Intelligence Workshop', 'Paris', 'workshop', '2022-09-01', '09:00:00', '2022-09-02', '17:00:00'),
(6, 'Blockchain Conference', 'Singapore', 'conference', '2022-10-05', '09:00:00', '2022-10-06', '18:00:00'),
(7, 'Mobile App Development Seminar', 'Sydney', 'seminar', '2022-11-10', '13:00:00', '2022-11-10', '17:00:00'),
(8, 'Cloud Computing Workshop', 'Tokyo', 'workshop', '2022-12-10', '11:00:00', '2022-12-11', '16:00:00'),
(9, 'Data Analytics Conference', 'New Delhi', 'conference', '2023-01-15', '08:00:00', '2023-01-17', '18:00:00'),
(10, 'Artificial Intelligence Seminar', 'Toronto', 'seminar', '2023-02-20', '10:00:00', '2023-02-20', '14:00:00');

INSERT INTO Organization_ VALUES
(1, 'ABC Inc.', '123 Main St, New York'),
(2, 'XYZ Corporation', '456 Park Ave, San Francisco'),
(3, 'LMN Ltd.', '789 Oxford St, London'),
(4, 'PQR Pvt. Ltd.', '321 Michigan Ave, Chicago'),
(5, 'DEF Corp.', '567 Champs-Elys�es, Paris'),
(6, 'GHI Co.', '101 Orchard Rd, Singapore'),
(7, 'JKL Enterprises', '246 Martin Pl, Sydney'),
(8, 'NOP Group', '999 Ginza, Tokyo'),
(9, 'QRS Industries', '555 Connaught Place, New Delhi'),
(10, 'TUV Corp.', '777 Bay St, Toronto');

INSERT INTO Participants VALUES
(1, 'John Smith', '1990-05-01', 'M', 1),
(2, 'Jane Doe', '1995-01-15', 'F', 2),
(3, 'David Lee', '1988-07-20', 'M', 3),
(4, 'Amy Chen', '1992-09-10', 'F', 4),
(5, 'Richard Kim', '1987-04-05', 'M', 5),
(6, 'Sophie Martin', '1991-12-25', 'F', 6),
(7, 'Michael Brown', '1994-03-18', 'M', 7),
(8, 'Anna Davis', '1989-11-05', 'F', 8),
(9, 'Robert Johnson', '1993-06-30', 'M', 9),
(10, 'Emily Wilson', '1996-02-28', 'F', 10);

INSERT INTO Sponsors VALUES
(1, 1, 5000),
(1, 2, 3000),
(2, 3, 10000),
(2, 4, 8000),
(3, 5, 6000),
(4, 6, 7500),
(5, 7, 9000),
(6, 8, 5000),
(7, 9, 12000),
(8, 10, 15000);

INSERT INTO Attended VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 2),
(1, 3),
(2, 3),
(3, 3),
(4, 3),
(5, 3),
(6, 4),
(7, 4),
(8, 4),
(9, 4),
(10, 4);

--q1---------------------------------------------------
select e.type_, e.Ename,year(e.start_date) as Year,(
	select count(PID)
	from Attended 
	where EID = e.EID) NoOfParticipants
from Event_ e
where e.EID in(
	select EID
	from Attended
	group by EID
	having count(PID) > 10)
group by e.EID,e.type_, e.Ename,year(e.start_date);

--q2---------------------------------------------------
select p.PID,(
	select e.Ename
	from Event_ e
	where e.EID = a.EID) EventName
from Participants p left join Attended a on p.PID = a.PID

--q3---------------------------------------------------
select P.Pname
from Participants P
where not exists (
    select EID
    from Attended A1
    where A1.PID = P.PID
    except
    select EID
    from Attended A2
    where A2.PID = (select PID from Participants where Pname = 'Hakaan Ali')
)
and not exists (
    select EID
    from Attended A2
    where A2.PID = (select PID from Participants where Pname = 'Hakaan Ali')
    except
    select EID
    from Attended A1
    where A1.PID = P.PID
) and p.Pname != 'Hakaan Ali';

--q4---------------------------------------------------

select p.Pname
from Participants p join Attended a on p.PID = a.PID
	join Event_ e1 on a.EID = e1.EID
where e1.type_ = 'seminar' and year(e1.start_date) = 2022
group by p.PID,p.Pname
having count(e1.EID) = (
	select count(e2.EID)
	from Event_ e2
	where e2.type_ = 'seminar' and year(e2.start_date) = 2022
	)

--q5---------------------------------------------------
create view sp as
	select s.EID,s.OID,e.type_
	from Sponsors s join Event_ e on s.EID = e.EID

select distinct s1.OID, s2.OID
from Sponsors s1, Sponsors s2
where s1.OID < s2.OID
and not exists(
    select *
    from (
        select distinct type_
        from sp
        where OID = s1.OID
    ) as s1events
    full outer join (
        select distinct type_
        from sp
        where OID = s2.OID
    ) as s2events
    on s1events.type_ = s2events.type_
    where s1events.type_ is NULL or s2events.type_ is NULL
)

--q6---------------------------------------------------

select o.Oname
from Organization_ o
where o.OID not in (
	select s.OID from Sponsors s
	where s.EID in(
		select e.EID
		from Event_ e
		where type_ = 'conference'))

--q7---------------------------------------------------

select p.Pname, year(GETDATE()) - year(p.bdate) as Age
from Participants p
where year(GETDATE()) - year(p.bdate) > (
	select avg(year(GETDATE()) - year(pa.bdate))
	from Participants pa
	)

--q8---------------------------------------------------

create view minCount as
	select e.EID,count(a1.PID) as participantCount
	from Event_ e left join Attended a1 on e.EID = a1.EID
	where YEAR(e.start_date) = 2022
	group by e.EID

select e.EID,e.Ename
from Event_ e left join Attended a on e.EID = a.EID
where year(e.start_date) = 2022
group by e.EID,e.Ename
having count(a.PID) = (
	select min(participantCount)
	from minCount 
)

--q9---------------------------------------------------

select o.Oname
from Organization_ o
where o.OID in (
	select distinct OID
	from Sponsors
	)

--q10--------------------------------------------------

select a.PID
from Attended a
where a.EID in (
	select e.EID
	from Event_ e 
	where e.start_date = '2003-01-25'
	)
and a.EID in(
	select e.EID	
	from Organization_ o join Sponsors s on o.OID = s.OID
		join Event_ e on e.EID = s.EID
	where o.Oname = 'Techlogix'
	)

--q11--------------------------------------------------

select p.Pname
from Participants p
where p.PID in(
	select a.PID
	from Attended a
	group by a.PID
	having count(*) = 5
	)

--q12--------------------------------------------------

select a.PID, COUNT(a.EID) EventsAttended
from Attended a
where a.EID in(
	select e.EID
	from Event_ e
	where year(e.start_date) = 2022
	)
group by a.PID

--q13--------------------------------------------------

select o.OID,o.Oname
from Organization_ o join Sponsors s on o.OID = s.OID
where s.amount = (
	select max(s.amount)
	from Sponsors s
	where s.EID in (
		select e.EID
		from Event_ e
		where year(e.start_date)=2022
		)
	)

select o.OID,o.Oname
from Organization_ o join Sponsors s on o.OID = s.OID
where s.amount = (
	select min(s.amount)
	from Sponsors s
	where s.EID in (
		select e.EID
		from Event_ e
		where year(e.start_date)=2022
		)
	)

--q14--------------------------------------------------

select o.Oname
from Organization_ o
where o.OID in(
	select s.OID
	from Sponsors s
	where s.EID in(
		select e.EID
		from Event_ e
		where e.type_ = 'seminar' and e.start_date like '2022-12%'
		)
	)
intersect
select o.Oname
from Organization_ o
where o.OID in(
	select s.OID
	from Sponsors s
	where s.EID in(
		select e.EID
		from Event_ e
		where e.type_ = 'workshop' and e.start_date like '2022-12%'
		)
	)

--q15--------------------------------------------------

select p.Pname
from Participants p
where p.PID in(
	select a.PID
	from Attended a
	where a.EID in(
		select  e.EID
		from Event_ e
		where e.type_ = 'seminar'
		)
	)
except
select p.Pname
from Participants p
where p.PID in(
	select a.PID
	from Attended a
	where a.EID in(
		select  e.EID
		from Event_ e
		where e.type_ = 'conference'
		)
	)

--qA------------------------------------

create view partA as
	select p.Pname,e.Ename,e.type_,day(e.end_date) - day(e.start_date) daysLasted
	from Participants p join Attended a on p.PID = a.PID join Event_ e on a.EID = e.EID

select * from partA

--qB------------------------------------
create view partB as
	select o.Oname,COUNT(EID) eventsSponsored,sum(amount) totalAmount
	from Organization_ o join Sponsors s on o.OID = s.OID
	group by o.OID,o.Oname
	having count(EID) > 3

--qC------------------------------------

create trigger sponsorAlert
on Sponsors
for insert,update
as
if exists(
	select *
	from Sponsors s
	where s.amount >100000
	)
begin
	print'A Sponsor has sponsored more than 100k!'
end

insert into Sponsors values (5,6,110000);

--qD------------------------------------

create trigger eventCancelled
on Event_
after delete
as
print 'An Event has been canceled'

delete from Event_ where Event_.EID = 9

insert into Event_ values(9, 'Data Analytics Conference', 'New Delhi', 'conference', '2023-01-15', '08:00:00', '2023-01-17', '18:00:00')


select * from Event_;
select * from Organization_;
select * from Participants;
select * from Sponsors;
select * from Attended;