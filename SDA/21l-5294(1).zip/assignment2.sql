-- create database EventDB;

use EventDB;

create table Event_(
	EID int primary key NOT NULL,
    Ename varchar(20),
    location varchar(50),
    type_ varchar(20) check(type_ = 'seminar' or type_ = 'workshop' or type_ = 'conference'),
    start_date date,
    start_time time,
    end_date date,
    end_time time
);

create table Organization_(
	OID int primary key NOT NULL,
    Oname varchar(20),
    address varchar(50)
);

create table Participants(
	PID int primary key NOT NULL,
    Pname varchar(20),
    bdate date,
    gender char(1),
    OID int,
    foreign key (OID) references Organization_(OID) on update cascade on delete set NULL
);

create table Sponsors(
	EID int NOT NULL,
    OID int NOT NULL,
    amount int,
    primary key (EID,OID),
    foreign key (EID) references Event_(EID) on update cascade on delete cascade,
    foreign key (OID) references Organization_(OID) on update cascade on delete cascade
);

create table Attended(
	PID int NOT NULL,
    EID int NOT NULL,
    primary key (EID,PID),
    foreign key (EID) references Event_(EID) on update cascade on delete cascade,
    foreign key (PID) references Participants(PID) on update cascade on delete cascade
);

insert into Event_ values
	(1,'Tech Summit','Lahore','conference','2022-12-01','06:00:00','2022-12-03','06:00:00'),
    (2,'Leadership Seminar','Lahore','seminar','2023-01-01','01:00:00','2023-01-04','06:00:00'),
    (3,'Writing Workshop','Islamabad','workshop','2003-01-023','04:00:00','2003-01-26','05:00:00'),
    (4,'Marketing Conference','Karachi','conference','2022-12-31','06:00:00','2023-01-03','06:00:00'),
    (5,'Educations Symposium','Faisalabad','seminar','2003-01-023','04:00:00','2003-01-26','05:00:00');

insert into Organization_ values
	(1,'Techlogix','2200 Mission College Blvd,CA 95054, USA'),
    (2,'Google','1600 Amphitheatre Parkway, CA 94043, USA'),
    (3,'Apple','Apple Park, 1 Apple Park Way, USA'),
    (4,'Microsoft','One Microsoft Way, Redmond, USA'),
    (5,'IBM','IBM Corporation, Armonk, NY 10504, USA');
    
insert into Participants values
	(1,'Sarah','2007-01-01','F',NULL),
    (2,'Imran','2001-05-09','M',1),
    (3,'Ali','2003-02-03','M',4),
    (4,'Khadija','1998-02-01','F',3),
    (5,'Karen','2000-05-05','F',2);

insert into Sponsors values
	(1,1,1000),
    (1,2,2000),
    (1,3,3000),
    (1,4,4000),
    (1,5,5000),
    (2,1,2300),
    (2,2,5400),
    (2,3,6700),
    (3,4,3400),
    (3,5,1200),
    (3,1,6000),
    (4,3,1000),
    (4,2,5000),
    (4,1,2500);
    
insert into Attended values
	(1,1),
    (1,2),
    (1,3),
    (1,4),
    (1,5),
    (2,1),
    (2,2),
    (2,3),
    (3,4),
    (3,5),
    (3,1),
    (4,3),
    (4,2);

-- q1    
select EID, Ename
from Event_;

-- q2
select EID,Ename,start_time
from Event_
where start_date <= '2023-01-03' and end_date >= '2023-01-03';

-- q3
select Pname
from Participants
where gender = 'F' and bdate >= '1998-02-17' and OID is NULL;

-- q4
select distinct Oname
from Organization_ as o join Sponsors as s on o.OID = s.OID;

-- q5
select distinct a.PID
from (((Organization_ as o join Sponsors as s on o.OID = s.OID) join Attended as a on a.EID = s.EID)
	join event_ as e on e.EID = a.EID)
where o.Oname = 'Techlogix' and e.start_date <= '2023-01-03' and e.end_date >= '2023-01-03';

-- q6
select o.Oname
from ((Organization_ as o join Sponsors as s on o.OID = s.OID) join Event_ as e on s.EID = e.EID)
except
select o.Oname
from ((Organization_ as o join Sponsors as s on o.OID = s.OID) join Event_ as e on s.EID = e.EID)
where e.type_ = 'seminar';

-- q7
select a.PID
from Attended as a
group by a.PID
having count(PID) = 5;

-- q8
select a.PID, count(PID) as 'Events Attended'
from Attended as a
group by a.PID;

-- q9
select max(amount) as "Maximum", min(amount) as "Minimum", avg(amount) as "Average"
from Sponsors;

-- q10
select o.Oname
from ((Organization_ as o join Sponsors as s on o.OID = s.OID) join Event_ as e on s.EID = e.EID)
where e.type_ = 'seminar'
intersect
select o.Oname
from ((Organization_ as o join Sponsors as s on o.OID = s.OID) join Event_ as e on s.EID = e.EID)
where e.type_ = 'workshop';

-- q11
select  p.Pname
from ((Participants as p join Attended as a on p.PID = a.PID) join Event_ as e on a.EID = e.EID)
where e.type_ = 'seminar'
except
select  p.Pname
from ((Participants as p join Attended as a on p.PID = a.PID) join Event_ as e on a.EID = e.EID)
where e.type_ = 'conference';

-- q12
(select a.PID
from (Event_ as e join Attended as a on e.EID = a.EID)
where start_date <= '2023-01-03' and end_date >= '2023-01-03')
union
(select PID
from Participants
except
select PID
from Attended);









 

    
-- select * from event_;
-- select * from organization_;
-- select * from participants;
-- select * from sponsors;
    
    









