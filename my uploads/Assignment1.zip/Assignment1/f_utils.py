import numpy as np

def tanh(a):
    return np.tanh(a)

def tanh_derivative(a):
    return 1 - np.tanh(a)**2

def relu(a):
    return np.maximum(0, a)

def sigmoid(a):
    return 1/(1 + np.exp(-a))

def relu_derivative(a):
    return (a > 0).astype(a.dtype)

def sigmoid_derivative(a):
    return np.exp(-a) / ((1 + np.exp(-a)) ** 2)

def lrelu(a, k):
    return np.where(a > 0, a, k * a)

def lrelu_derivative(a, k):
    return np.where(a > 0, 1, k)
