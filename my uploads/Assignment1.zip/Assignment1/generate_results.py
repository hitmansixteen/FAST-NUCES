import numpy as np
import matplotlib.pyplot as plt
from f_load_dataset import load_dataset
from neural_network import NeuralNetwork

########################################################################################
learning_rate = 1e-3
epochs = 100
mini_batch_size = 25
num_of_neurons = 100

# Load dataset
train_x, train_t, val_x, val_t, test_x, test_t = load_dataset()

# Function to train and evaluate a neural network
def train_and_evaluate(activation_func):
    layer_dim = [1] + [num_of_neurons] * 5 + [1]  # 5 hidden layers
    activations = [None] + [activation_func] * 5 + ['identity']
    
    nn = NeuralNetwork(layer_dim, activations, learning_rate, epochs, mini_batch_size)
    nn.train(train_x, train_t, val_x, val_t)
    
    train_loss, _ = nn.test(train_x, train_t)
    test_loss, _ = nn.test(test_x, test_t)
    
    return np.round(train_loss, 4), np.round(test_loss, 4)

# Train and evaluate for different activation functions
train_loss_sigmoid, test_loss_sigmoid = train_and_evaluate('sigmoid')
train_loss_tanh, test_loss_tanh = train_and_evaluate('tanh')
train_loss_relu, test_loss_relu = train_and_evaluate('relu')
train_loss_lrelu, test_loss_lrelu = train_and_evaluate('lrelu')

# Figure 4: Activation Functions vs. Error
train_loss = [train_loss_sigmoid, train_loss_tanh, train_loss_relu, train_loss_lrelu]
test_loss = [test_loss_sigmoid, test_loss_tanh, test_loss_relu, test_loss_lrelu]
act_func = ['sigmoid', 'tanh', 'relu', 'lrelu']
width = 0.3

plt.figure(figsize=(8, 6))
plt.bar(np.arange(len(train_loss)), train_loss, width=width, label='Train Loss')
plt.bar(np.arange(len(test_loss)) + width, test_loss, width=width, label='Test Loss')
plt.xticks(np.arange(len(act_func)) + width / 2, act_func)
plt.xlabel('Activation Functions')
plt.ylabel('Loss')
plt.legend()
plt.title('Loss vs. Activation Functions')
plt.savefig('Figure 5.png', dpi=300)
plt.show()

########################################################################################
# Figure 5: Activation Functions vs. Hidden Layers
hidden_layer_configs = [1, 2, 3, 5, 10]
test_error_sigmoid = []
test_error_tanh = []
test_error_relu = []
test_error_lrelu = []

for hl in hidden_layer_configs:
    layer_dim = [1] + [num_of_neurons] * hl + [1]  # Varying hidden layers

    test_error_sigmoid.append(train_and_evaluate('sigmoid')[1])
    test_error_tanh.append(train_and_evaluate('tanh')[1])
    test_error_relu.append(train_and_evaluate('relu')[1])
    test_error_lrelu.append(train_and_evaluate('lrelu')[1])

plt.figure(figsize=(8, 6))
plt.plot(hidden_layer_configs, test_error_sigmoid, 'o--', color='darkorange', label='Sigmoid')
plt.plot(hidden_layer_configs, test_error_tanh, 'o--', color='red', label='Tanh')
plt.plot(hidden_layer_configs, test_error_relu, 'o--', color='purple', label='ReLU')
plt.plot(hidden_layer_configs, test_error_lrelu, 'o--', color='blue', label='LReLU')

plt.xticks(hidden_layer_configs)
plt.xlabel('Number of Hidden Layers')
plt.ylabel('Test Loss')
plt.legend()
plt.title('Loss vs. Hidden Layers')
plt.savefig('Figure 6.png', dpi=300)
plt.show()
