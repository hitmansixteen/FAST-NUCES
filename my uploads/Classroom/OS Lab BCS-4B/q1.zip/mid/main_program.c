#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc,char**argv){
	
	char * const*input = argv[1];
	char * const*output = argv[2];
	char * const*pipe_ = argv[3];
	
	
	
	pid_t pid1,pid2;
	int status;
	
	pid1 = fork();
	if(pid1==0){
	execv("./word_count.o","word_count.o",input,pipe_,NULL);
	
	}
	wait_pid(pid1,&status,0);
	pid2 = fork();
	if(pid2==0){
	
	}
	wait_pid(pid2,&status,0);

	return 0;
}
