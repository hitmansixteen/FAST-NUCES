#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc,char**argv){
	
	char* filename = argv[1];
	//int fd = open(argv[2],O_RDWR);
	
	FILE* file = fopen(filename,O_RDONLY);
	char ch;
	int num=1;
	
	while(ch=fgetc(file)){
		if(ch == ' ' || ch == '\n')
			num++;
	}
	printf("%d\n",num);
	
	fclose(file);

	return 0;
}
