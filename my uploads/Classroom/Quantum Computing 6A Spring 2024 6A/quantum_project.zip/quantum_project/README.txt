========================libraries the must be installed===================
pip install qiskit
pip install matplotlib
pip install jupyter
pip install numpy
pip install qiskit_ibm_runtime
pip install qiskit_aer
pip install seaborn
--refer to the pip list at the end of the notebook
==========assuming you have python already installed :)=======================