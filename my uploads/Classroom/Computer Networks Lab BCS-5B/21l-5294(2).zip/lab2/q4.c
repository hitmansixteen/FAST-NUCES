#include <stdio.h>
int main ()
{
  int x = 0x3210;
  char *c = (char*) &x;
 
  printf ("*c is: 0x%x\n", *c);
  if (*c == 0x10)
  {
    printf ("byte ordering is little endian. \n");
  }
  else
  {
     printf ("byte ordering is big endian. \n");
  }
 
  return 0;
}
