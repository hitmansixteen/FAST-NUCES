#include <stdio.h>
#include<unistd.h>
int main ()
{
  
  while(1){
	  FILE *fp = fopen("/proc/stat","r");
	  
	  char cpu[255];
	  float total=0,notInUse=0,inUse=0;
	  int user,nice,system,idle,iowait,irq,softirq;
	  
	fscanf(fp,"%s %d %d %d %d %d %d %d",cpu,&user,&nice,&system,&idle,&iowait,&irq,&softirq);
	printf("%s %d %d %d %d %d %d %d \n",cpu,user,nice,system,idle,iowait,irq,softirq);
	total = user + nice + system + idle + iowait + irq +softirq;
	notInUse = ((idle + iowait)/total)*100;
	inUse = 100-notInUse;
	printf("Total: %lf\nIDLE: %lf\nIn Use: %lf\n",total,notInUse,inUse);
	sleep(1);

	fclose(fp);
  }
  
  
  
  return 0;
}
