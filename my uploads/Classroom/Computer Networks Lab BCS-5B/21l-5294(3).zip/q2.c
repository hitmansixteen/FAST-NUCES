#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>

int main(){
	
	FILE *fp1,*fp2;
	char buff1[255];
	char buff2[255];
	
	fp1 = fopen("Input_File.txt","r");
	fp2 = fopen("output.txt","w");
	int j=0;
	while(fgets(buff1,255,(FILE*)fp1)){
	
		int size = strlen(buff1);
	
		int i;
		
	
		for(i=0;i<size;i++){
			if(buff1[i] >= '0' && buff1[i]<='9'){
				buff2[j]=buff1[i];
				j++;
			}
		}
	}
	buff2[j]='\0';
	fprintf(fp2,"%s",buff2);
	
	fclose(fp1);
	fclose(fp2);

	return 0;
}
