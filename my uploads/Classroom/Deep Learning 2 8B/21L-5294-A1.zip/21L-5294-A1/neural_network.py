import numpy as np
import matplotlib.pyplot as plt
from f_utils import *
import copy
from f_check_gradient import check_gradients
from sklearn.utils import shuffle

class NeuralNetwork():
  
    def __init__(self, num_neurons, activations_func, learning_rate, num_epochs, mini_batch_size):     
        self.num_neurons = num_neurons
        self.activations_func = activations_func
        self.learning_rate = learning_rate
        self.num_iterations = num_epochs
        self.mini_batch_size = mini_batch_size
        self.num_layers = len(self.num_neurons) - 1
        self.parameters = dict()
        self.net = dict()
        self.net1 = dict()
        self.grads = dict()

    def initialize_parameters(self):
        print("Num of layers", self.num_layers)
        for l in range(1, self.num_layers + 1):
            if self.activations_func[l] == 'relu':
                self.parameters['W%s' % l] = np.random.randn(self.num_neurons[l], self.num_neurons[l-1]) / np.sqrt(self.num_neurons[l-1] / 2.)
            else:                
                self.parameters['W%s' % l] = np.random.randn(self.num_neurons[l], self.num_neurons[l-1]) / np.sqrt(self.num_neurons[l - 1])
            self.parameters['b%s' % l] = np.zeros((self.num_neurons[l], 1))
            # print("weights and biases initialization", self.parameters['W%s' % l].shape, self.parameters['b%s' % l].shape)

    def fprop(self, batch_input): 
        self.net1[0] = batch_input
        for l in range(1, self.num_layers + 1):
            Z = np.dot(self.parameters['W' + str(l)], self.net1[l-1]) + self.parameters['b' + str(l)]
            self.net[l] = Z
            act = self.activations_func[l]
            if act == 'sigmoid':
                self.net1[l] = sigmoid(Z)
            elif act == 'tanh':
                self.net1[l] = tanh(Z)
            elif act == 'relu':
                self.net1[l] = relu(Z)
            elif act == 'lrelu':
                self.net1[l] = lrelu(Z, 0.01)
            elif act == 'identity' or act is None:
                self.net1[l] = Z
            else:
                self.net1[l] = Z
      
    def calculate_loss(self, batch_target):       
        output = self.net1[self.num_layers]
        loss = 0.5 * np.mean((output - batch_target) ** 2)
        return loss
        
    def update_parameters(self, epoch):
        for l in range(1, self.num_layers + 1):
            self.parameters['W' + str(l)] -= self.learning_rate * self.grads['dW' + str(l)]
            self.parameters['b' + str(l)] -= self.learning_rate * self.grads['db' + str(l)]
    
    def bprop(self, batch_target):
        m = batch_target.shape[1]
        self.grads = {}
        # derivative of MSE loss with respect to the output
        dA = (self.net1[self.num_layers] - batch_target) / m
        for l in range(self.num_layers, 0, -1):
            Z = self.net[l]
            act = self.activations_func[l]
            if act == 'sigmoid':
                dZ = dA * sigmoid_derivative(Z)
            elif act == 'tanh':
                dZ = dA * tanh_derivative(Z)
            elif act == 'relu':
                dZ = dA * relu_derivative(Z)
            elif act == 'lrelu':
                dZ = dA * lrelu_derivative(Z, 0.01)
            elif act == 'identity' or act is None:
                dZ = dA
            else:
                dZ = dA
            A_prev = self.net1[l-1]
            self.grads['dW' + str(l)] = np.dot(dZ, A_prev.T)
            self.grads['db' + str(l)] = np.sum(dZ, axis=1, keepdims=True)
            dA = np.dot(self.parameters['W' + str(l)].T, dZ)
      
    def test(self, test_x, test_t):
        self.fprop(test_x)
        loss = self.calculate_loss(test_t)
        output = self.net1[self.num_layers]
        return loss, output
    
    def plot_loss(self, loss, val_loss):        
        plt.figure()
        fig = plt.gcf()
        plt.plot(loss, linewidth=3, label="train")
        plt.plot(val_loss, linewidth=3, label="val")
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.title('learning rate = %s, hidden layers = %s' % (self.learning_rate, self.num_layers - 1))
        plt.grid()
        plt.legend()
        plt.show()
        fig.savefig('plot_loss.png')
        
    def plot_gradients(self):
        avg_l_g = []
        grad = copy.deepcopy(self.grads)
        for l in range(1, self.num_layers + 1):
            weights_grad = grad['dW' + str(l)]
            avg_g = np.mean(np.abs(weights_grad))
            avg_l_g.append(avg_g)
        layers = ['layer %s' % l for l in range(self.num_layers + 1)]
        fig = plt.gcf()
        plt.xticks(range(len(layers)), layers)
        plt.xlabel('layers')
        plt.ylabel('average gradients magnitude')
        plt.bar(range(len(avg_l_g)), avg_l_g, color='red', width=0.2) 
        plt.show() 
        fig.savefig('plot_gradients.png')
    
    def train(self, train_x, train_y, val_x, val_y):
        train_x, train_y = shuffle(train_x, train_y, random_state=0)
        self.initialize_parameters()        
        train_loss = []
        val_loss = []  
        num_samples = train_y.shape[1]       
        check_grad = True
        grad_ok = 0
        
        for i in range(0, self.num_iterations):
            for idx in range(0, num_samples, self.mini_batch_size):
                minibatch_input = train_x[:, idx:idx + self.mini_batch_size]
                minibatch_target = train_y[:, idx:idx + self.mini_batch_size]
                
                if check_grad:
                    grad_ok = check_gradients(self, minibatch_input, minibatch_target)
                    if grad_ok == 0:
                        print("gradients are not ok!\n")
                
                if grad_ok == 1:
                    check_grad = False  # run grad check only on the first mini-batch
                    self.fprop(minibatch_input)
                    loss = self.calculate_loss(minibatch_target)
                    self.bprop(minibatch_target)
                    self.update_parameters(i)
                   
            train_loss.append(loss)
            self.fprop(val_x)
            va_loss = self.calculate_loss(val_y)
            val_loss.append(va_loss)
            # print("Epoch %i: training loss %f, validation loss %f" % (i, loss, va_loss))
        self.plot_loss(train_loss, val_loss)
        self.plot_gradients()
