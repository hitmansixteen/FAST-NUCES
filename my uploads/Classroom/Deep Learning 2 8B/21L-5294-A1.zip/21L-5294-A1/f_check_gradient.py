import numpy as np
from f_utils import *
import copy

def check_gradients(self, train_X, train_t):
    eps = 1e-5
    grad_ok = 0 
    
    self.fprop(train_X)
    self.bprop(train_t)
    
    for l in range(1, self.num_layers + 1):

        W = self.parameters['W' + str(l)]
        Analytical_grad_W = self.grads['dW' + str(l)]
        Numerical_grad_W = np.zeros_like(W)
        
        i_t = np.nditer(W, flags=['multi_index'], op_flags=['readwrite'])
        while not i_t.finished:
            i_x = i_t.multi_index
            i = W[i_x]
            
            W[i_x] = i + eps
            self.fprop(train_X)
            loss1 = self.calculate_loss(train_t)
            
            W[i_x] = i - eps
            self.fprop(train_X)
            loss2 = self.calculate_loss(train_t)
            
            W[i_x] = i
            
            Numerical_grad_W[i_x] = (loss1 - loss2) / (2.0 * eps)
            i_t.iternext()
        
        diff = (np.linalg.norm(Numerical_grad_W - Analytical_grad_W))  / (np.linalg.norm(Numerical_grad_W) + np.linalg.norm(Analytical_grad_W))
        # print(Numerical_grad_W, Analytical_grad_W)
        
        if diff > eps:
            print("layer %s W gradients are not ok" % l)
            grad_ok = 0
        else:
            print("layer %s W gradients are ok" % l)
            grad_ok = 1  


        b = self.parameters['b' + str(l)]
        Analytical_grad_b = self.grads['db' + str(l)]
        Numerical_grad_b = np.zeros_like(b)
        
        i_b = np.nditer(b, flags=['multi_index'], op_flags=['readwrite'])
        while not i_b.finished:
            i_x = i_b.multi_index
            i = b[i_x]
            
            b[i_x] = i + eps
            self.fprop(train_X)
            loss1 = self.calculate_loss(train_t)
            
            b[i_x] = i - eps
            self.fprop(train_X)
            loss2= self.calculate_loss(train_t)
            
            b[i_x] = i
            
            Numerical_grad_b[i_x] = (loss1 - loss2) / (2.0 * eps)
            i_b.iternext()
        

        diff = (np.linalg.norm(Numerical_grad_b - Analytical_grad_b))  / (np.linalg.norm(Numerical_grad_b) + np.linalg.norm(Analytical_grad_b))
        # print(Numerical_grad_b, Analytical_grad_b)

        Numerical_grad = np.concatenate([Numerical_grad_W.flatten(), Numerical_grad_b.flatten()])
        Analytical_grad = np.concatenate([Analytical_grad_W.flatten(), Analytical_grad_b.flatten()])

        diff = (np.linalg.norm(Numerical_grad - Analytical_grad))  / (np.linalg.norm(Numerical_grad) + np.linalg.norm(Analytical_grad))
        # print(Numerical_grad, Analytical_grad)
        
        if diff > eps:
            print("layer %s b gradients are not ok" % l)
            grad_ok = 0
        else:
            print("layer %s b gradients are ok" % l)
            grad_ok = 1 

    return grad_ok
