#include <iostream>
#include <pthread.h>
#include <fstream>

using namespace std;

bool flag = true;

void readArrayFromFile(string filename, int *arr, int l, int r)
{
    ifstream file(filename);
    for (int i = l; i < r; i++)
        file >> arr[i];
    file.close();
}

void writeArrayToFile(string filename, int *arr, int l, int r)
{
    ofstream file(filename);

    for (int i = l; i < r; i++)
        file << arr[i] << " ";
    file.close();
}

struct node
{
    int data;
    struct node *next;
};
struct node *front = NULL, *rear = NULL;

int num;

void enqueue(int x)
{
    struct node *temp = (struct node *)malloc(sizeof(struct node));
    temp->data = x;
    temp->next = NULL;

    if (!front && !rear)
        front = rear = temp;
    else
    {
        rear->next = temp;
        rear = rear->next;
    }
}

void print()
{
    cout << "Elements in Queue: ";
    struct node *temp = front;
    while (temp)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void *readFromFile(void *param)
{
    fstream file("q2.txt");

    while (!file.eof())
    {
        file >> num;
    }
    flag = false;

    file.close();
    pthread_exit(NULL);
}

void *addIntoQueue(void *param)
{
    while (flag)
    {
        enqueue(num);
    }
    pthread_exit(NULL);
}

int main()
{
    long x;
    cout << "Enter the size of Array: ";
    cin >> x;

    int size = x;
    int *array = new int[size];

    for (int i = 0; i < size; i++)
    {
        array[i] = rand() % size;
    }

    writeArrayToFile("q2.txt", array, 0, size);

    pthread_t thread1,
        thread2;
    pthread_create(&thread1, NULL, &readFromFile, NULL);
    pthread_create(&thread2, NULL, &addIntoQueue, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    readArrayFromFile("q2.txt", array, 0, size);

    print();

    exit(EXIT_SUCCESS);
}