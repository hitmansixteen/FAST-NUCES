#include <iostream>
#include <fstream>
#include <thread>
#include <time.h>
#include <string.h>
#include <math.h>

using namespace std;

// Merge Sort==================================
void merge(int *arr, int p, int q, int r)
{
    int n1 = q - p + 1;
    int n2 = r - q;

    int *L = new int[n1];
    int *M = new int[n2];

    for (int i = 0; i < n1; i++)
        L[i] = arr[p + i];
    for (int j = 0; j < n2; j++)
        M[j] = arr[q + 1 + j];
    int i, j, k;
    i = 0;
    j = 0;
    k = p;
    while (i < n1 && j < n2)
    {
        if (L[i] <= M[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = M[j];
            j++;
        }
        k++;
    }
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2)
    {
        arr[k] = M[j];
        j++;
        k++;
    }

    delete[] L;
    delete[] M;
}
void mergeSort(int *arr, int l, int r)
{
    if (l < r)
    {
        int m = l + (r - l) / 2;

        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}
// Selection Sort==================================
void selectionSort(int *arr, int n)
{
    int minIndex;
    for (int i = 0; i < n - 1; i++)
    {
        minIndex = i;
        for (int j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[minIndex])
                minIndex = j;
        }
        if (minIndex != i)
            swap(arr[minIndex], arr[i]);
    }
}
// Insertion Sort==================================
void insertionSort(int *arr, int n)
{
    int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}
// Quick Sort==================================
int partition(int *array, int low, int high)
{

    int pivot = array[high];

    int i = (low - 1);
    for (int j = low; j < high; j++)
    {
        if (array[j] <= pivot)
        {
            i++;
            swap(array[i], array[j]);
        }
    }
    swap(array[i + 1], array[high]);

    return (i + 1);
}
void quickSort(int *array, int low, int high)
{
    if (low < high)
    {
        int p = partition(array, low, high);
        quickSort(array, low, p - 1);
        quickSort(array, p + 1, high);
    }
}
//======================================================
void readArrayFromFile(string filename, int *arr, int l, int r)
{
    ifstream file(filename);
    for (int i = l; i < r; i++)
        file >> arr[i];
    file.close();
}

void writeArrayToFile(string filename, int *arr, int l, int r)
{
    ofstream file(filename);

    for (int i = l; i < r; i++)
        file << arr[i] << " ";
    file.close();
}

//======================================================

time_t printCurrentTime()
{
    auto currentTime = chrono::system_clock::now();
    time_t currentTimeC = chrono::system_clock::to_time_t(currentTime);
    return currentTimeC;
    // cout << ctime(&currentTimeC) << endl;
}

//======================================================

void *mergeThread(void *param)
{
    time_t myTime = time(NULL);
    string t = to_string(pthread_self());
    string s = "Merge Sort Thread starts thread ID " + t + " on " + ctime(&myTime) + "\n";
    cout << s;
    long x = (long)param;
    int size = x;
    int *array = new int[size];
    readArrayFromFile("Unsorted_00.txt", array, 0, size);
    mergeSort(array, 0, size - 1);
    writeArrayToFile("merge.txt", array, 0, size);

    delete[] array;
    myTime = time(NULL);
    cout << "Merge Sort Thread ends on " << ctime(&myTime) << endl;
    pthread_exit(0);
}
//======================================================
void *selectionThread(void *param)
{
    time_t myTime = time(NULL);
    string t = to_string(pthread_self());
    string s = "Selection Sort Thread starts thread ID " + t + " on " + ctime(&myTime) + "\n";
    cout << s;
    long x = (long)param;
    int size = x;
    int *array = new int[size];
    readArrayFromFile("Unsorted_01.txt", array, 0, size);
    selectionSort(array, size);
    writeArrayToFile("selection.txt", array, 0, size);

    delete[] array;
    myTime = time(NULL);
    cout << "Selection Sort Thread ends on " << ctime(&myTime) << endl;
    pthread_exit(0);
}
//======================================================
void *insertionThread(void *param)
{
    time_t myTime = time(NULL);
    string t = to_string(pthread_self());
    string s = "Insertion Sort Thread starts thread ID " + t + " on " + ctime(&myTime) + "\n";
    cout << s;
    long x = (long)param;
    int size = x;
    int *array = new int[size];
    readArrayFromFile("Unsorted_02.txt", array, 0, size);

    insertionSort(array, size);
    writeArrayToFile("insertion.txt", array, 0, size);
    delete[] array;
    myTime = time(NULL);
    cout << "Insertion Sort Thread ends on " << ctime(&myTime) << endl;
    pthread_exit(0);
}
//======================================================
void *quickThread(void *param)
{
    time_t myTime = time(NULL);
    string t = to_string(pthread_self());
    string s = "Quick Sort Thread starts thread ID " + t + " on " + ctime(&myTime) + "\n";
    cout << s;
    long x = (long)param;
    int size = x;
    int *array = new int[size];
    readArrayFromFile("Unsorted_03.txt", array, 0, size);

    quickSort(array, 0, size - 1);
    writeArrayToFile("quick.txt", array, 0, size);
    delete[] array;
    myTime = time(NULL);
    cout << "Quick Sort Thread ends on " << ctime(&myTime) << endl;
    pthread_exit(0);
}
//======================================================
int main()
{
    srand(time(NULL));
    long x;
    cout << "Enter the size of Array: ";
    cin >> x;

    int size = x;
    int *array = new int[size];

    for (int i = 0; i < size; i++)
    {
        array[i] = rand() % size;
    }

    long size1 = size / 4;
    long size2 = size - (size1 * 3);

    writeArrayToFile("Unsorted_00.txt", array, 0, size1);
    writeArrayToFile("Unsorted_01.txt", array, size1, size1 * 2);
    writeArrayToFile("Unsorted_02.txt", array, size1 * 2, size1 * 3);
    writeArrayToFile("Unsorted_03.txt", array, size1 * 3, size);

    pthread_t threadMerge, threadSelection, threadInsertion, threadQuick;

    pthread_create(&threadMerge, NULL, &mergeThread, (void *)size1);
    pthread_create(&threadSelection, NULL, &selectionThread, (void *)size1);
    pthread_create(&threadInsertion, NULL, &insertionThread, (void *)size1);
    pthread_create(&threadQuick, NULL, &quickThread, (void *)size2);

    void *join;

    pthread_join(threadMerge, &join);
    pthread_join(threadSelection, &join);
    pthread_join(threadInsertion, &join);
    pthread_join(threadQuick, &join);

    readArrayFromFile("merge.txt", array, 0, size1);
    readArrayFromFile("selection.txt", array, size1, size1 * 2);
    readArrayFromFile("insertion.txt", array, size1 * 2, size1 * 3);
    readArrayFromFile("quick.txt", array, size1 * 3, size);

    mergeSort(array, 0, size - 1);

    writeArrayToFile("sorted.txt", array, 0, size);

    delete[] array;
    exit(EXIT_SUCCESS);
}