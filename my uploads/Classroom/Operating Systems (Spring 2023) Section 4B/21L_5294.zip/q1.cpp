#include <iostream>
#include <chrono>
#include <queue>

using namespace std;

class AlarmClock
{
public:
    chrono::steady_clock::time_point alarmTime;
    bool stopAlarm;
    int time;
    AlarmClock()
    {
        stopAlarm = false;
        alarmTime = chrono::steady_clock::now();
    }
    void goToSleepFor(int howLong)
    {
        time = howLong;
        alarmTime = chrono::steady_clock::now() + chrono::seconds(howLong);
        std::cout << "Alarm set for " << howLong << " seconds from now.\n";
    }

    void snoozeAlarm()
    {
        alarmTime += chrono::seconds(10);
        cout << "Alarm for " << time << " seconds Snoozed for 10 seconds\n";
    }
};
queue<AlarmClock> q;
AlarmClock alarm;

int main()
{
    int noOfAlarms, snooze;
    cout << "Enter How many alarms you want: ";
    cin >> noOfAlarms;

    int len;

    for (int i = 0; i < noOfAlarms; i++)
    {
        cout << "How long you want Alarm " << i + 1 << " for: ";
        cin >> len;
        alarm.goToSleepFor(len);
        q.push(alarm);
    }

    while (!q.empty())
    {
        if (q.front().alarmTime <= chrono::steady_clock::now())
        {
            cout << "Alarm! Alarm!\n";
            cout << "Do you want to Snooze this Alarm for " << q.front().time << " seconds: ";
            cin >> snooze;
            if (snooze)
                q.front().snoozeAlarm();
            else
            {
                q.front().stopAlarm = 1;
                cout << "Alarm for " << q.front().time << " seconds Stopped!\n";
            }
        }
        alarm = q.front();
        q.pop();
        if (!alarm.stopAlarm)
        {
            q.push(alarm);
        }
    }

    return 0;
}
