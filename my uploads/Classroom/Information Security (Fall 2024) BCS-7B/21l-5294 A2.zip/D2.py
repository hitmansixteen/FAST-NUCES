def validate_hex_values(hex_block):
    if not all(c in "0123456789abcdefABCDEF" for c in hex_block):
        print(f"Error: '{hex_block}' contains invalid hexadecimal characters.")
        return None


    if len(hex_block) > 4:
        print("Error: You must enter <=4 characters.")
        return None
    
    hex_block = hex_block.zfill(4)
    
    hex_number = int(hex_block, 16)  
    
    return hex_block, hex_number

SubNibbles = {
    0b0000: 0b1010,  # 0 -> A
    0b0001: 0b0000,  # 1 -> 0
    0b0010: 0b1001,  # 2 -> 9
    0b0011: 0b1110,  # 3 -> E
    0b0100: 0b0110,  # 4 -> 6
    0b0101: 0b0011,  # 5 -> 3
    0b0110: 0b1111,  # 6 -> F
    0b0111: 0b0101,  # 7 -> 5
    0b1000: 0b0001,  # 8 -> 1
    0b1001: 0b1101,  # 9 -> D
    0b1010: 0b1100,  # A -> C
    0b1011: 0b0111,  # B -> 7
    0b1100: 0b1011,  # C -> B
    0b1101: 0b0100,  # D -> 4
    0b1110: 0b0010,  # E -> 2
    0b1111: 0b1000   # F -> 8
}

ReverseSubNibbles = {
    0b1010: 0b0000,  # A -> 0
    0b0000: 0b0001,  # 0 -> 1
    0b1001: 0b0010,  # 9 -> 2
    0b1110: 0b0011,  # E -> 3
    0b0110: 0b0100,  # 6 -> 4
    0b0011: 0b0101,  # 3 -> 5
    0b1111: 0b0110,  # F -> 6
    0b0101: 0b0111,  # 5 -> 7
    0b0001: 0b1000,  # 1 -> 8
    0b1101: 0b1001,  # D -> 9
    0b1100: 0b1010,  # C -> A
    0b0111: 0b1011,  # 7 -> B
    0b1011: 0b1100,  # B -> C
    0b0100: 0b1101,  # 4 -> D
    0b0010: 0b1110,  # 2 -> E
    0b1000: 0b1111   # 8 -> F
}

def reverse_substitute_nibbles(hex_number):
    substituted_number = 0   
    for shift in range(12, -1, -4):
        current_nibble = (hex_number >> shift) & 0b1111
        substituted_nibble = ReverseSubNibbles[current_nibble]
        substituted_number = (substituted_number << 4) | substituted_nibble

    return substituted_number


def substitute_nibbles(hex_number):
    substituted_number = 0   
    for shift in range(12, -1, -4):
        current_nibble = (hex_number >> shift) & 0b1111
        substituted_nibble = SubNibbles[current_nibble]
        substituted_number = (substituted_number << 4) | substituted_nibble

    return substituted_number

def ShiftRow(hex_number):
    hex_str = hex(hex_number)[2:]
    hex_str = hex_str.zfill(4)
    nibbles = list(hex_str)
    
    shifted_nibbles = [nibbles[2], nibbles[1], nibbles[0], nibbles[3]]
    shifted_hex_str = ''.join(shifted_nibbles)
    
    shifted_number = int(shifted_hex_str, 16)

    return shifted_number

def mix_columns(hex_number,n):

    def least_significant_bit(x):
        return x & 1
    
    def fourth_bit_set(x):
        return (x & 0b10000)

    def gf_mult(a,b):
        m=0
        while b>0:
            if least_significant_bit(b):
                m = m ^ a
            a = a << 1

            if fourth_bit_set(a):
                a = a ^ 0b10011
            
            b = b >> 1
        return m



    c0 = (hex_number >> 12) & 0b1111
    c1 = (hex_number >> 8) & 0b1111
    c2 = (hex_number >> 4) & 0b1111
    c3 = hex_number & 0b1111

    d0 = gf_mult(n[0], c0) ^ gf_mult(n[1], c1)
    d1 = gf_mult(n[1], c0) ^ gf_mult(n[0], c1)
    d2 = gf_mult(n[0], c2) ^ gf_mult(n[1], c3)
    d3 = gf_mult(n[1], c2) ^ gf_mult(n[0], c3)

    result = (d0 << 12) | (d1 << 8) | (d2 << 4) | d3
    return result

def generate_round_keys(key_number):
    Rcon1 = 0b1110
    Rcon2 = 0b1010


    w0 = (key_number >> 12) & 0b1111
    w1 = (key_number >> 8) & 0b1111
    w2 = (key_number >> 4) & 0b1111
    w3 = key_number & 0b1111

    w4 = w0 ^ SubNibbles[w3] ^ Rcon1
    w5 = w1 ^ w4
    w6 = w2 ^ w5
    w7 = w3 ^ w6

    w8 = w4 ^ SubNibbles[w7] ^ Rcon2
    w9 = w5 ^ w8
    w10 = w6 ^ w9
    w11 = w7 ^ w10

    K1 = (w4 << 12) | (w5 << 8) | (w6 << 4) | w7
    K2 = (w8 << 12) | (w9 << 8) | (w10 << 4) | w11

    return K1, K2



def encrypt(hex_number,key_number):
    #Round1
    sub_nibbles1 = substitute_nibbles(hex_number)
    K1,K2 = generate_round_keys(key_number)
    xor1 = sub_nibbles1 ^ K1
    mix_columns1 = mix_columns(xor1,[1,4])
    shift_row1 = ShiftRow(mix_columns1)

    #Round2
    sub_nibbles2 = substitute_nibbles(shift_row1)
    xor2 = sub_nibbles2 ^ K2
    shift_row2 = ShiftRow(xor2)

    return shift_row2



def decrypt(hex_number,key_number):
    #Round2
    K1, K2 = generate_round_keys(key_number)
    shift_row2 = ShiftRow(hex_number)
    xor2 = K2 ^ shift_row2
    sub_nibbles2 = reverse_substitute_nibbles(xor2)
    
    #Round1
    shift_row1 = ShiftRow(sub_nibbles2)
    mix_columns1 = mix_columns(shift_row1,[9,2])
    xor1 = K1 ^ mix_columns1
    sub_nibbles1 = reverse_substitute_nibbles(xor1)

    return sub_nibbles1
hex_block = input("Enter the ciphertext block: ").strip()
hex_value, hex_number = validate_hex_values(hex_block)
hex_block = input("Enter the key: ").strip()
key_value, key_number = validate_hex_values(hex_block)


decrypt_number = decrypt(hex_number,key_number)
print(f"Decrypted block: {hex(decrypt_number)[2:].zfill(4)}")





