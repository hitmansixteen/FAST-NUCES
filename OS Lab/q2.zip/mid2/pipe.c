#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc,char**argv){
	
	mkfifo(argv[1],S_IRUSR | S_IWUSR);
	return 0;
}
