#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc,char**argv){
	char *in = argv[1];
	char *out = argv[2];
	char *pipe_ = argv[3];
	FILE *file;
	int fd = open(pipe_,O_RDWR);
	pid_t pid1,pid2;
	char buff[1024];
	pid1 = fork();
	if(pid1 == 0){  
		execv("./file_reader","file_reader","mypipe","output.txt",NULL);
	}
	wait(NULL);
	pid2 = fork()
	if(pid2==0){
		execv("./file_writer","file_writer","input.txt","mypipe",NULL);
	}
	wait(NULL);
	
	close(fd);
	return 0;
}
