#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc,char**argv){
    
    char *pipe_ = argv[1];
    char *out = argv[2];
    
    char buff[1024];
    
    file = fopen(in,O_RDONLY);
	int i=0;
	while(buff[i]=fgetc(file)){i++;}
	buff[i++]='\0';
	write(fd,buff,1024);
    fclose(file);
    file = fopen("output.txt",O_WRONLY);
    i=0;
    while(buff[i]!='\0'){
        fputc(buff[i],file);
        i++;
    }
    fclose(file);
    close(fd);

	return 0;
}
