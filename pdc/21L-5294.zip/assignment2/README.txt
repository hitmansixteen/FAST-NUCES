==========================run the code below to generate input files==============================
gcc generate.c -o generate
./generate 4096
============================run the code below to perform matrix multiplication for OPENMP=========================
gcc matrixmul.c -o matrixmul
./matrixmul <inputfile> <outputfile>
=================== for gpu and tpu code=======================
open tpuvsgpu.ipynb in google colab
go to runtime
change runtime to t4 gpu to run the gpu code and TPU to run tpu code