// omp_get_num_threads() To get currently executing threads
// omp_get_thread_num()  To get id of the calling thread
// OMP_NUM_THREADS       To set max threads in a team (Dont confue it with above function!)

#include<stdio.h>
#include<omp.h>


int main()
{

	printf("[Thread ID: %d] No of threads just beofre a parallel region: %d\n", omp_get_thread_num(), omp_get_num_threads());
	
	#pragma omp parallel
	{
		printf("[Thread ID: %d] No of threads inside a parallel region: %d\n", omp_get_thread_num(), omp_get_num_threads());

	}

	printf("[Thread ID: %d] No of threads after a parallel region: %d\n", omp_get_thread_num(), omp_get_num_threads());


	return 0;
}
