#include <stdio.h>
#include <omp.h>


int main()
{



	#pragma omp parallel 
	{
		#pragma omp for
		//{   //<---- compiler will complain if we put a bracket here
			for(size_t i=0; i<50; i++)
			{
				printf("[Thread ID: %d] Loop iteration no: %lu\n", omp_get_thread_num(), i);

			}//end of for



		//}




	}






	return 0;
}
