#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <omp.h>

// Purpose: Reduction
// Usually its a good pratice to compile with all warning on: gcc -o g -fopenmp g.c -Wall
// Not initialzing reduction variables can have un-intended consequences
//

void print2DArray(size_t rowCount, size_t colCount, int array[rowCount][colCount]);
void fill2DArrayWithRandomInts(size_t rowCount, size_t colCount, int array[rowCount][colCount]);

int main()
{
	printf("Max thread count = %d\n\n", omp_get_max_threads());
	size_t i = 0;
	const size_t n = 20;
	const size_t maxThreads = omp_get_max_threads();
	int a[maxThreads][n] ={};
	size_t myid = -1;
	int b = 23;
	int minimum = INT_MAX;
	int maximum = INT_MIN;
	//int minimum;
	//int maximum;

	fill2DArrayWithRandomInts(maxThreads, n, a);
	
	print2DArray(maxThreads, n-1, a);

	#pragma omp parallel default(none) reduction(min:minimum) reduction(max:maximum) private(i,myid) shared(a,n)        
	{
		printf("Min = %d   Max = %d \n", minimum, maximum);
		myid = omp_get_thread_num();
		for (i=0; i<n-1; i++)
		{
			if (a[myid][i] < minimum) minimum = a[myid][i];
			if (a[myid][i] > maximum) maximum = a[myid][i];
			
		}
		
		printf("After: Min = %d   Max = %d \n", minimum, maximum);	
	}//end of parallel block

	//print2DArray(maxThreads, n-1, a);

	printf("Global Min: %d\n", minimum);
	printf("Global Max: %d\n", maximum);



}


void print2DArray(size_t rowCount, size_t colCount, int array[rowCount][colCount])
{
	for(size_t i=0; i < rowCount; i++)
	{
		for(size_t j=0; j<colCount; j++)
			printf("%d  ", array[i][j]);
		
		printf("\n");
	}


	printf("\n");
}


void fill2DArrayWithRandomInts(size_t rowCount, size_t colCount, int array[rowCount][colCount])
{
    // Seed the random number generator
    //srand(time(NULL));

    // Fill the array with random integers
    for (size_t i = 0; i < rowCount; i++) {
        for (size_t j = 0; j < colCount; j++) {
            array[i][j] = rand() % 2; // Generate random number between 0 and 1
        }
    }
}
