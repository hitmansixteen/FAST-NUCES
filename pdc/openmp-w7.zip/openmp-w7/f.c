#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

// Purpose: Reduction 

void print2DArray(size_t rowCount, size_t colCount, int array[rowCount][colCount]);
void fill2DArrayWithRandomInts(size_t rowCount, size_t colCount, int array[rowCount][colCount]);

int main()
{
	printf("Max thread count = %d\n\n", omp_get_max_threads());
	size_t i = 0;
	const size_t n = 20;
	const size_t maxThreads = omp_get_max_threads();
	int a[maxThreads][n] ={};
	size_t myid = -1;
	int b = 23;

	fill2DArrayWithRandomInts(maxThreads, n, a);
	
	print2DArray(maxThreads, n, a);

	#pragma omp parallel default(none) reduction(+:b) private(i,myid) shared(a,n)        
	{
		myid = omp_get_thread_num();
		for (i=0; i<n-1; i++)
		{
			b += a[myid][i];
		}
		a[myid][n-1] = b;	
	}//end of parallel block
	int finalSum = b;

	print2DArray(maxThreads, n, a);

	printf("Final sum after reduction: %d\n", finalSum);



}


void print2DArray(size_t rowCount, size_t colCount, int array[rowCount][colCount])
{
	for(size_t i=0; i < rowCount; i++)
	{
		for(size_t j=0; j<colCount; j++)
			printf("%d  ", array[i][j]);
		
		printf("\n");
	}


	printf("\n");
}


void fill2DArrayWithRandomInts(size_t rowCount, size_t colCount, int array[rowCount][colCount])
{
    // Seed the random number generator
    //srand(time(NULL));

    // Fill the array with random integers
    for (size_t i = 0; i < rowCount; i++) {
        for (size_t j = 0; j < colCount; j++) {
            array[i][j] = rand() % 2; // Generate random number between 0 and 1
        }
    }
}
