#include <stdio.h>
#include <omp.h>



int main()
{

	int x = 100;


	
	//#pragma omp parallel default(none) private(x)
	#pragma omp parallel default(none) firstprivate(x)
	{
	 	//int x = 200;

		printf("[Thread ID: %d] Value of x is: %d\n", omp_get_thread_num(), x);

	}

	printf("[Thread ID: %d] Value of x is: %d\n", omp_get_thread_num(), x);





	return 0;
}
