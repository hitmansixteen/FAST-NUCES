#include <stdio.h>
#include <omp.h>

// Purpose: shorthand for parallel for

int main()
{



	#pragma omp parallel for 
	//{
		for(size_t i=0; i<50; i++)
		{
			printf("[Thread ID: %d] Loop iteration no: %lu\n", omp_get_thread_num(), i);

		}//end of for

	//}






	return 0;
}
