#include <stdio.h>
#include <omp.h>

// Purpose: Scheduling and chunksize

#define ARRAY_SIZE 10

int main() {
    int array[ARRAY_SIZE];
    int i;

    // Initialize the array
    for (i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i;
    }

    printf("Static scheduling:\n");
    #pragma omp parallel for schedule(static)
    for (i = 0; i < ARRAY_SIZE; i++) {
        printf("Thread %d processing element %d\n", omp_get_thread_num(), array[i]);
    }

    printf("\nStatic scheduling with chunk size of 10:\n");
    #pragma omp parallel for schedule(static, 10)
    for (i = 0; i < ARRAY_SIZE; i++) {
        printf("Thread %d processing element %d\n", omp_get_thread_num(), array[i]);
    }

    printf("\nDynamic scheduling:\n");
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < ARRAY_SIZE; i++) {
        printf("Thread %d processing element %d\n", omp_get_thread_num(), array[i]);
    }

    printf("\nGuided scheduling:\n");
    #pragma omp parallel for schedule(guided)
    for (i = 0; i < ARRAY_SIZE; i++) {
        printf("Thread %d processing element %d\n", omp_get_thread_num(), array[i]);
    }

    printf("\nAuto scheduling:\n");
    #pragma omp parallel for schedule(auto)
    for (i = 0; i < ARRAY_SIZE; i++) {
        printf("Thread %d processing element %d\n", omp_get_thread_num(), array[i]);
    }

    return 0;
}

