#include <stdio.h>
#include <unistd.h>
#include <omp.h>

int main() {
    int num_threads;

    // Parallel region
    #pragma omp parallel
    {
        num_threads = omp_get_num_threads();
        printf("Thread %d: Number of threads in the team: %d\n", omp_get_thread_num(), num_threads);
        
        // Master block
        #pragma omp master
        {
            printf("[Thread ID: %d] Master thread: I am the master, and I execute this block.\n", omp_get_thread_num());
            printf("[Thread ID: %d] Master thread: There are %d threads in the team.\n", omp_get_thread_num(), num_threads);
	    printf("Master sleeping....\n");
	    sleep(5);
	    printf("Master awake...\n");
        }

	printf("Thread %d: After master block: %d\n", omp_get_thread_num(), num_threads);

    }

    return 0;
}

