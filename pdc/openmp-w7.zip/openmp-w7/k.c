#include <stdio.h>
#include <omp.h>


// Purpose: Use of Single

int main() {
    int num_threads;

    // Example 1: single directive with a single thread executing the block
    #pragma omp parallel num_threads(4)
    {
        #pragma omp single
        {
            num_threads = omp_get_num_threads();
            printf("Example 1: Thread %d executes this block with %d threads\n", omp_get_thread_num(), num_threads);
        }
    }

    // Example 2: single directive outside parallel region (only one thread executes)
    #pragma omp single
    {
        printf("Example 2: This block is executed by a single thread outside the parallel region.\n");
    }


    // Non-Example 1: single directive with nowait clause
    #pragma omp parallel num_threads(4)
    {
        #pragma omp single nowait
        {
            printf("[Thread ID: %d]Non-Example 2: This block can execute without waiting for other threads to complete.\n", omp_get_thread_num());
        }
        printf("Thread %d continues after the single directive.\n", omp_get_thread_num());
    }

    return 0;
}

