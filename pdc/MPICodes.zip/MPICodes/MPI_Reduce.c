#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define ARRAY_SIZE 4

int main(int argc, char *argv[]) {
    int rank, size;
    int data[ARRAY_SIZE];
    int sum = 0;
    int root = 0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Initialize data with rank for each process
    for (int i = 0; i < ARRAY_SIZE; i++) {
        data[i] = rank + 1; // Rank + 1 to avoid zeros
    }

    // Perform local summation
    int local_sum = 0;
    for (int i = 0; i < ARRAY_SIZE; i++) {
        local_sum += data[i];
    }

    // Reduce local sums to obtain global sum
    MPI_Reduce(&local_sum, &sum, 1, MPI_INT, MPI_SUM, root, MPI_COMM_WORLD);

    if (rank == root) {
        printf("Process %d computed the sum: %d\n", rank, sum);
    }

    MPI_Finalize();
    return 0;
}

