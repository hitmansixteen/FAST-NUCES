#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int message1 = 10, message2 = 20;
    int recv_message1, recv_message2;
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size != 2) {
        printf("This program requires exactly 2 processes.\n");
        MPI_Finalize();
        return 1;
    }

    if (rank == 0) {
        // Process 0 sends message1 with tag 1
        MPI_Bsend(&message1, 1, MPI_INT, 1, 1, MPI_COMM_WORLD);
        // Process 0 sends message2 with tag 2
        MPI_Bsend(&message2, 1, MPI_INT, 1, 2, MPI_COMM_WORLD);
    } else if (rank == 1) {
        // Process 1 receives message2 with tag 2
        MPI_Recv(&recv_message2, 1, MPI_INT, 0, 2, MPI_COMM_WORLD, &status);
        printf("Received message2: %d\n", recv_message2);
        // Process 1 receives message1 with tag 1
        MPI_Recv(&recv_message1, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
        printf("Received message1: %d\n", recv_message1);
    }

    MPI_Finalize();
    return 0;
}

