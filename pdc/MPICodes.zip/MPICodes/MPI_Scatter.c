#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define ARRAY_SIZE 8

int main(int argc, char *argv[]) {
    int rank, size;
    int root = 0;
    int sendbuf[ARRAY_SIZE];
    int recvbuf;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == root) {
        // Initialize send buffer with values
        for (int i = 0; i < ARRAY_SIZE; i++) {
            sendbuf[i] = i * i;
        }
    }

    // Scatter the array from the root process to all other processes
    // Note in the following send and receive count is 1
    MPI_Scatter(sendbuf, 1, MPI_INT, &recvbuf, 1, MPI_INT, root, MPI_COMM_WORLD);

    // Print received value for each process
    printf("Process %d received: %d\n", rank, recvbuf);

    MPI_Finalize();
    return 0;
}

