#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, new_rank, new_size;
    MPI_Comm new_comm;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    // Split MPI_COMM_WORLD into even and odd rank groups
    int color = rank % 2; // color is 0 for even ranks, 1 for odd ranks
    MPI_Comm_split(MPI_COMM_WORLD, color, rank, &new_comm);

    // Determine rank and size within the new communicator
    MPI_Comm_rank(new_comm, &new_rank);
    MPI_Comm_size(new_comm, &new_size);

    printf("Rank %d in MPI_COMM_WORLD belongs to color %d in new_comm. "
           "New rank = %d, New size = %d\n",
           rank, color, new_rank, new_size);

    MPI_Comm_free(&new_comm); // Free the new communicator
    MPI_Finalize();
    return 0;
}

