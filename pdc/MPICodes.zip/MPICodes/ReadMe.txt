// Following copied from https://brandonrozek.com/blog/openmpi-fedora/

To use use the OpenMPI compilers (mpicc, mpic++, etc.) and mpirun on Fedora, you’ll need to install the openmpi package as well as set up the envionrment paths correctly.

==To install:==

sudo dnf install openmpi openmpi-devel


Then to set up the environmental variables correctly so that PATH is set. You’ll need to use the environment modules program installed by default on Fedora. First, you’ll need to source it:

==source /etc/profile.d/modules.sh==


Now you can load in the OpenMPI module

==module load mpi/openmpi-x86_64==

Finally, with these changes you can use the compiler tools and runner. Do note that you’ll have to source and load the OpenMPI module for every shell you open unless you add it within $HOME/.bashrc.


==Use mpicc for compilation and mpirun or mpiexec to run the program.==


== To see functions in mpi, you can find mpi.h and view in in some editior.
$ sudo find . -name  "mpi.h"

On my box it was at the following path:
$ vi /usr/include/openmpi-x86_64/mpi.h 

==

