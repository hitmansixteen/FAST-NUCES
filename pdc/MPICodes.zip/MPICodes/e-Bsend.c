#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int message = 10;
    int bufsize;
    int *buffer;
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Determine the size of the buffer needed
    MPI_Pack_size(1, MPI_INT, MPI_COMM_WORLD, &bufsize);
    bufsize += MPI_BSEND_OVERHEAD; // Account for MPI_BSEND_OVERHEAD

    // Allocate a buffer
    buffer = (int *)malloc(bufsize);
    
    // Attach the buffer
    MPI_Buffer_attach(buffer, bufsize);

    if (rank == 0) {
        // Try to send the first message
        printf("Rank %d: Trying to send the first message...\n", rank);
        MPI_Bsend(&message, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        
        // Try to send the second message quickly after the first one
        printf("Rank %d: Trying to send the second message quickly...\n", rank);
        MPI_Bsend(&message, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
    } else if (rank == 1) {
        // Receive the messages
        MPI_Recv(&message, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Rank %d: Received first message: %d\n", rank, message);
        
        MPI_Recv(&message, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Rank %d: Received second message: %d\n", rank, message);
    }

    // Detach and free the buffer
    MPI_Buffer_detach(&buffer, &bufsize);
    free(buffer);

    MPI_Finalize();
    return 0;
}

