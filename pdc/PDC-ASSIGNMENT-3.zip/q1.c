#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <inttypes.h>
#include <gmp.h>
#include <immintrin.h>
#include <sys/time.h>
#include <omp.h>
#include <mpi.h>

void matrixMulInt32(void **matrix1, void **matrix2, void **matrix3, int start, int end)
{
    __m256i a, b, mul;
    int64_t temp[4];
#pragma omp for collapse(2) private(a, b, mul, temp)
    for (int i = start; i < end; i++)
    {
        for (int j = 0; j < 4096; j++)
        {
            a = _mm256_set1_epi64x(*((int64_t *)matrix1[i] + j));
            for (int k = 0; k < 4096; k += 4)
            {
                b = _mm256_loadu_si256((__m256i *)((int64_t *)matrix2[j] + k));
                mul = _mm256_mul_epi32(a, b);
                _mm256_storeu_si256((__m256i *)temp, mul);

                for (int l = 0; l < 4; l++)
                {
                    *((__int128_t *)matrix3[i] + k + l) += temp[l];
                }
            }
        }
    }
}

void matrixMulInt64(void **matrix1, void **matrix2, void **matrix3, int start, int end)
{
    __m256i sum, a, b, mul, negA, negB, comp, zeros, mask, high, low, cross1, cross2, tempA, tempB;
    int64_t highs[4], lows[4], cross1s[4], cross2s[4], negativeA[4], negativeB[4], matrix[4];
    mpz_t h, l, c1, c2;
    mpz_inits(h, l, c1, c2, NULL);

#pragma omp for collapse(2) private(a, b, mul, sum, negA, negB, comp, zeros, mask, high, low, cross1, cross2, tempA, tempB, highs, lows, cross1s, cross2s, negativeA, negativeB, matrix, h, l, c1, c2)
    for (int i = start; i < end; i++)
    {
        for (int j = 0; j < 4096; j++)
        {
            sum = _mm256_setzero_si256();

            for (int k = 0; k < 4096; k += 4)
            {
                a = _mm256_loadu_si256((__m256i *)((int64_t *)matrix1[i] + k));

                for (int m = k; m < k + 4; m++)
                {
                    matrix[m - k] = *((int64_t *)matrix2[m] + j);
                }

                b = _mm256_loadu_si256((__m256i *)&matrix[0]);

                comp = _mm256_set1_epi64x(1LL << 63);

                negA = _mm256_and_si256(a, comp);
                negA = _mm256_cmpeq_epi64(negA, comp);

                negB = _mm256_and_si256(b, comp);
                negB = _mm256_cmpeq_epi64(negB, comp);

                zeros = _mm256_setzero_si256();

                mask = _mm256_cmpgt_epi64(zeros, a);
                a = _mm256_blendv_epi8(a, _mm256_sub_epi64(zeros, a), mask);

                mask = _mm256_cmpgt_epi64(zeros, b);
                b = _mm256_blendv_epi8(b, _mm256_sub_epi64(zeros, b), mask);

                low = _mm256_mul_epu32(a, b);

                tempB = _mm256_srli_epi64(b, 32);

                cross1 = _mm256_mul_epu32(a, tempB);

                tempA = _mm256_srli_epi64(a, 32);

                cross2 = _mm256_mul_epu32(tempA, b);

                high = _mm256_mul_epu32(tempA, tempB);

                _mm256_storeu_si256((__m256i *)highs, high);
                _mm256_storeu_si256((__m256i *)lows, low);
                _mm256_storeu_si256((__m256i *)cross1s, cross1);
                _mm256_storeu_si256((__m256i *)cross2s, cross2);
                _mm256_storeu_si256((__m256i *)negativeA, negA);
                _mm256_storeu_si256((__m256i *)negativeB, negB);

                for (int n = 0; n < 4; n++)
                {
                    mpz_set_ui(h, highs[n]);
                    mpz_set_ui(l, lows[n]);

                    mpz_set_ui(c1, cross1s[n]);

                    mpz_set_ui(c2, cross2s[n]);

                    mpz_mul_2exp(h, h, 64);
                    mpz_mul_2exp(c1, c1, 32);
                    mpz_mul_2exp(c2, c2, 32);

                    mpz_add(h, h, c1);
                    mpz_add(h, h, c2);
                    mpz_add(h, h, l);

                    if (negativeA[n] == UINT64_MAX && negativeB[n] == 0 || negativeA[n] == 0 && negativeB[n] == UINT64_MAX)
                    {
                        mpz_neg(h, h);
                    }

                    mpz_add(*((mpz_t *)matrix3[i] + j), *((mpz_t *)matrix3[i] + j), h);
                }
            }
        }
    }

    mpz_clears(h, l, c1, c2, NULL);
}

void matrixMulFloat32(void **matrix1, void **matrix2, void **matrix3, int start, int end)
{
    __m256d a, b, mul, add;

#pragma omp for collapse(2) private(a, b, mul, add)
    for (int i = start; i < end; i++)
    {
        for (int j = 0; j < 4096; j++)
        {
            a = _mm256_set1_pd(*((double *)matrix1[i] + j));

            for (int k = 0; k < 4096; k += 4)
            {
                b = _mm256_loadu_pd((double *)matrix2[j] + k);
                mul = _mm256_mul_pd(a, b);
                add = _mm256_loadu_pd((double *)matrix3[i] + k);
                add = _mm256_add_pd(add, mul);
                _mm256_storeu_pd((double *)matrix3[i] + k, add);
            }
        }
    }
}

void matrixMulFloat64(void **matrix1, void **matrix2, void **matrix3, int start, int end)
{
    __m256d a, b, mul, add;

#pragma omp for collapse(2) private(a, b, mul, add)
    for (int i = start; i < end; i++)
    {
        for (int j = 0; j < 4096; j++)
        {
            a = _mm256_set1_pd(*((double *)matrix1[i] + j));
            for (int k = 0; k < 4096; k += 4)
            {
                b = _mm256_loadu_pd((double *)matrix2[j] + k);
                mul = _mm256_mul_pd(a, b);
                add = _mm256_loadu_pd((double *)matrix3[i] + k);
                add = _mm256_add_pd(add, mul);
                _mm256_storeu_pd((double *)matrix3[i] + k, add);
            }
        }
    }
}

void print128(FILE *file, __int128_t value)
{
    if (value < 0)
    {
        fprintf(file, "-");
        value = -value;
    }

    if (value >= 10)
    {
        print128(file, value / 10);
    }
    fprintf(file, "%d", (int)(value % 10));
}

int main(int argc, char *argv[])
{

    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    printf("%d", size);
    int chunk_size = 4096 / size;
    int start_index = rank * chunk_size;
    int end_index = (rank == size - 1) ? 4096 : (start_index + chunk_size);

    struct timeval start, end;
    double total;

    double matrix1[4096][4096], matrix2[4096][4096], matrix3[4096][4096];
    int datatype;

    if (rank == 0){

        FILE *input = fopen(argv[1], "r");

        int opcode;
        char str[100];
        gettimeofday(&start, NULL);

        fscanf(input, "%d", &opcode);
        fscanf(input, "%d", &datatype);
        fscanf(input, "%s", str);

        matrix1 = (void **)malloc(4096 * sizeof(void *));
        matrix2 = (void **)malloc(4096 * sizeof(void *));
        matrix3 = (void **)malloc(4096 * sizeof(void *));

        for (int i = 1; i < size; i++){
            MPI_Ssend(&datatype, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
        }


        for (int i = 0; i < 4096; i++)
        {
            if (datatype == 2)
            {
                for (int j = 0; j < 4096; j++)
                {
                    double temp;
                    fscanf(input, "%lf", &temp);
                    *((double *)matrix1[i] + j) = temp;
                }
            }
            else if (datatype == 3)
            {
                matrix1[i] = (void *)malloc(4096 * sizeof(int64_t));
                matrix2[i] = (void *)malloc(4096 * sizeof(int64_t));
                matrix3[i] = (void *)malloc(4096 * sizeof(mpz_t));

                for (int j = 0; j < 4096; j++)
                {
                    int64_t temp;
                    fscanf(input, "%ld", &temp);
                    *((int64_t *)matrix1[i] + j) = temp;
                    mpz_set_si(*((mpz_t *)matrix3[i] + j), 0);
                }
            }
            else if (datatype == 1)
            {
                matrix1[i] = (void *)malloc(4096 * sizeof(int64_t));
                matrix2[i] = (void *)malloc(4096 * sizeof(int64_t));
                matrix3[i] = (void *)malloc(4096 * sizeof(__int128_t));

                for (int j = 0; j < 4096; j++)
                {
                    int temp;
                    fscanf(input, "%d", &temp);
                    *((int64_t *)matrix1[i] + j) = temp;
                    *((__int128_t *)matrix3[i] + j) = 0;
                }
            }
            else
            {
                matrix1[i] = (void *)malloc(4096 * sizeof(double));
                matrix1[i] = (void *)malloc(4096 * sizeof(double));
                matrix1[i] = (void *)malloc(4096 * sizeof(double));

                for (int j = 0; j < 4096; j++)
                {
                    double temp;
                    fscanf(input, "%lf", &temp);
                    *((double *)matrix1[i] + j) = temp;
                }
            }
        }

        for (int i = 1; i < size; i++){
            MPI_Ssend(matrix2, 16777216, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
        }

        fscanf(input, "%s", str);

        for (int i = 0; i < 4096; i++)
        {
            if (datatype == 2)
            {
                for (int j = 0; j < 4096; j++)
                {
                    double temp;
                    fscanf(input, "%lf", &temp);
                    *((double *)matrix2[i] + j) = temp;
                    *((double *)matrix3[i] + j) = 0;

                }
            }
            else if (datatype == 3)
            {
                for (int j = 0; j < 4096; j++)
                {
                    int64_t temp;
                    fscanf(input, "%ld", &temp);
                    *((int64_t *)matrix2[i] + j) = temp;
                }
            }
            else if (datatype == 1)
            {
                for (int j = 0; j < 4096; j++)
                {
                    int temp;
                    fscanf(input, "%d", &temp);
                    *((int64_t *)matrix2[i] + j) = temp;
                }
            }
            else
            {
                for (int j = 0; j < 4096; j++)
                {
                    double temp;
                    fscanf(input, "%lf", &temp);
                    *((double *)matrix2[i] + j) = temp;
                    *((double *)matrix3[i] + j) = 0;
                }
            }
        }

        for (int i = 1; i < size; i++){
            MPI_Ssend(matrix2, 16777216, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
        }
    }
    else {
        MPI_Status status;
        MPI_Recv(&datatype, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Recv(matrix1, 16777216, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Recv(matrix2, 16777216, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, &status);
    }

    fclose(input);

    gettimeofday(&end, NULL);

    total = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;

    printf("itime of rank%d: %lf\n", rank, total);
    gettimeofday(&start, NULL);
    // FILE *file = fopen("itime7.txt", "a");
    // if (file != NULL)
    // {
    //     fseek(file, 0, SEEK_END);
    //     long size = ftell(file);

    //     if (size == 0)
    //     {
    //         fprintf(file, "%lf", total);
    //     }
    //     else
    //     {
    //         fprintf(file, "\n%lf", total);
    //     }

    //     fclose(file);
    // }

    if (datatype == 1)
    {
#pragma omp parallel default(none) shared(matrix1, matrix2, matrix3, start_index, end_index)
        {
            matrixMulInt32(matrix1, matrix2, matrix3, start_index, end_index);
        }
    }
    else if (datatype == 2)
    {
#pragma omp parallel default(none) shared(matrix1, matrix2, matrix3, start_index, end_index)
        {
            matrixMulFloat32(matrix1, matrix2, matrix3, start_index, end_index);
        }
    }
    else if (datatype == 3)
    {
#pragma omp parallel default(none) shared(matrix1, matrix2, matrix3, start_index, end_index)
        {
            matrixMulInt64(matrix1, matrix2, matrix3, start_index, end_index);
        }
    }
    else
    {
#pragma omp parallel default(none) shared(matrix1, matrix2, matrix3, start_index, end_index)
        {
            matrixMulFloat64(matrix1, matrix2, matrix3, start_index, end_index);
        }
    }

    gettimeofday(&end, NULL);

    total = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;

    printf("ctime for rank%d: %lf\n", rank, total);

    // file = fopen("output_7.txt", "a");
    // if (file != NULL)
    // {
    //     fseek(file, 0, SEEK_END);
    //     long size = ftell(file);

    //     if (size == 0)
    //     {
    //         fprintf(file, "%lf", total);
    //     }
    //     else
    //     {
    //         fprintf(file, "\n%lf", total);
    //     }

    //     fclose(file);
    // }
    if (rank == 0)
    {
        for (int i = 1; i < size; i++){
            MPI_Status status;
            MPI_Recv(&matrix3[start_index], 4096 * (start_index - end_index), MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &status);
        }

        gettimeofday(&start, NULL);

        FILE *output = fopen(argv[2], "w");
        if (datatype == 1 || datatype == 3)
        {
            fprintf(output, "256 bit integer\n");
        }
        else
        {
            fprintf(output, "long double\n");
        }
        fprintf(output, "4096x4096\n");

        for (int i = 0; i < 4096; i++)
        {
            for (int j = 0; j < 4096; j++)
            {
                if (datatype == 2)
                {
                    fprintf(output, "%lf", *((double *)matrix3[i] + j));
                    if (j != 4095)
                        fprintf(output, " ");
                }
                else if (datatype == 3)
                {
                    mpz_out_str(output, 10, (*(mpz_t *)matrix3[i] + j));
                    if (j != 4095)
                        fprintf(output, " ");
                }
                else if (datatype == 1)
                {
                    print128(output, *((__int128_t *)matrix3[i] + j));
                    if (j != 4095)
                        fprintf(output, " ");
                }
                else
                {
                    fprintf(output, "%lf", *((double *)matrix3[i] + j));
                    if (j != 4095)
                        fprintf(output, " ");
                }
            }
            if (i != 4095)
                fprintf(output, "\n");
        }

        fclose(output);

        gettimeofday(&end, NULL);

        total = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;

        printf("otime of rank%d: %lf\n", rank, total);
    }
    else{
        MPI_Ssend(&matrix3[start_index], 4096 * (start_index - end_index), MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }
    for (int i = 0; i < 4096; i++)
    {
        free(matrix1[i]);
        free(matrix2[i]);
        if (datatype == 3)
        {
            for (int j = 0; j < 4096; j++)
            {
                mpz_clear(*(mpz_t *)matrix3[i] + j);
            }
        }

        free(matrix3[i]);
    }

    free(matrix1);
    free(matrix2);
    free(matrix3);

    // file = fopen("otime7.txt", "a");
    // if (file != NULL)
    // {
    //     fseek(file, 0, SEEK_END);
    //     long size = ftell(file);

    //     if (size == 0)
    //     {
    //         fprintf(file, "%lf", total);
    //     }
    //     else
    //     {
    //         fprintf(file, "\n%lf", total);
    //     }

    //     fclose(file);
    // }

    MPI_Finalize();
    return 0;
}
