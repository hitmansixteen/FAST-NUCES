
def show_menu():
    print("\nMenu:")
    print("0. Exit")
    print("1. Query")

def parse_output_file(output_file):
    local_dict = {}
    with open(output_file, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            key, value = line.split(":", 1)
            local_dict[key.strip()] = eval(value.strip())  # Convert the string representation of list to list
    return local_dict

def query_global_dict(global_dict):
    key = input("Enter the key to query: ")
    if key in global_dict:
        print(f"Value for key '{key}': {global_dict[key]}")
    else:
        print("Not Found")

output_file = "q3global_reduce.txt"
global_dict = parse_output_file(output_file)


while True:
    show_menu()
    choice = input("Enter your choice: ")
    if choice == "0":
        print("Exiting...")
        break
    elif choice == "1":
        query_global_dict(global_dict)
    else:
        print("Invalid choice. Please try again.")
