from mrjob.job import MRJob
from mrjob.step import MRStep
import nltk
from nltk.corpus import words

nltk.download('words')
english_words = set(words.words())

class MRReverseIndex(MRJob):

    def mapper(self, _, line):
        reverse_index = {}
        current_url = None
        line = line.strip()
        if line.startswith("WARC-Target-URI:"):
            current_url = line.split(":", 1)[1].strip()
        elif "WARC" in line or "Content" in line or current_url is None:
            return
        elif line:
            words = line.split()
            for word in words:
                short_word = word.lower()
                if short_word not in english_words:
                    if word not in english_words:
                        continue
                if word not in reverse_index:
                    reverse_index[word] = []
                if current_url not in reverse_index[word]:
                    reverse_index[word].append(current_url)
        for word, urls in reverse_index.items():
            yield word, urls

    def reducer(self, word, urls):
        url_list = list(set().union(*urls))
        yield word, url_list

if __name__ == '__main__':
    MRReverseIndex.run()
