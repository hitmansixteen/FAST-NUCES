from mrjob.job import MRJob
from mrjob.step import MRStep
import nltk
from nltk.corpus import words

nltk.download('words')
english_words = set(words.words())

class MRWordCount(MRJob):

    def mapper(self, _, line):
        word_counter = {}
        line = line.strip()
        if "WARC" in line or "Content" in line:
            return
        elif line:
            words = line.split()
            for word in words:
                short_word = word.lower()
                if short_word not in english_words:
                    if word not in english_words:
                        continue
                yield word, 1

    def reducer(self, word, counts):
        yield word, sum(counts)

if __name__ == '__main__':
    MRWordCount.run()
