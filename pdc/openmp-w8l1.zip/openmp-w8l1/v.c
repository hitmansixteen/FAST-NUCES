#include <stdio.h>
#include <omp.h>

int main() {
    double start_time, end_time, elapsed_time;
    double tick;

    // Get the tick resolution of the timer
    tick = omp_get_wtick();
    printf("Timer resolution: %e seconds\n", tick);

    // Start the timer
    start_time = omp_get_wtime();

    // Perform some computation or parallel work
    #pragma omp parallel for num_threads(8)
    for (int i = 0; i < 1000000; i++) {
        // Some parallel work
        double result = i * i;
    }

    // Stop the timer
    end_time = omp_get_wtime();

    // Calculate elapsed time
    elapsed_time = end_time - start_time;

    // Print the elapsed time
    printf("Elapsed time: %.6f seconds\n", elapsed_time);

    return 0;
}


/*
 *
 * 
 * code to get monotonically increasing time
#include <stdio.h>
#include <time.h>

int main() {
    struct timespec start_time, end_time;
    double elapsed_time;

    clock_gettime(CLOCK_MONOTONIC, &start_time); // Start the timer

    // Perform some computation or parallel work

    clock_gettime(CLOCK_MONOTONIC, &end_time); // Stop the timer

    // Calculate elapsed time
    elapsed_time = (end_time.tv_sec - start_time.tv_sec) +
                   (end_time.tv_nsec - start_time.tv_nsec) / 1.0e9;

    printf("Elapsed time: %.6f seconds\n", elapsed_time);

    return 0;
}

 *
 *
 *
 */
