#include <stdio.h>
#include <omp.h>

int main() {
    int i, j;
    int n = 5;
    int m = 3;
    int matrix[n][m];

    // Initialize matrix
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            matrix[i][j] = i * m + j;
        }
    }

    // Print the matrix before modification
    printf("Matrix before modification:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    // Parallel loop with collapse
    #pragma omp parallel for collapse(2)
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            // Modify each element of the matrix
            matrix[i][j] *= 2;
        }
    }

    // Print the matrix after modification
    printf("\nMatrix after modification:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}

