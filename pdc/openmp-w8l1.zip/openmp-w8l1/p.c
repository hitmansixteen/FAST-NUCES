//Purpose: Learning about locks

#include <stdio.h>
#include <omp.h>

int main() {
    omp_lock_t lock;
    int shared_variable = 0;

    // Initialize the lock
    omp_init_lock(&lock);

    #pragma omp parallel num_threads(4)
    {
        int tid = omp_get_thread_num();

        // Acquire the lock
        omp_set_lock(&lock);

        // Critical section
        shared_variable++;
        printf("Thread %d incremented the shared_variable. Current value: %d\n", tid, shared_variable);

        // Release the lock
        omp_unset_lock(&lock);
    }

    // Destroy the lock
    omp_destroy_lock(&lock);

    printf("Final shared_variable value: %d\n", shared_variable);

    return 0;
}

