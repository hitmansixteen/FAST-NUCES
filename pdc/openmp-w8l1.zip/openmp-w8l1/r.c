#include <stdio.h>
#include <omp.h>

int main() {
    int outer_threads = 2;
    int inner_threads = 4;

    // Enable nested parallelism
    omp_set_nested(1);

    #pragma omp parallel num_threads(outer_threads)
    {
        int outer_thread_id = omp_get_thread_num();
        printf("Outer thread %d\n", outer_thread_id);

        #pragma omp parallel num_threads(inner_threads)
        {
            int inner_thread_id = omp_get_thread_num();
            printf("Inner thread %d (outer thread %d)\n", inner_thread_id, outer_thread_id);
        }
    }

    return 0;
}

