// See documentation of functions: omp_get_level() retuns numbr of parallel regions
// GCC doc sasya: This function returns the thread identification number for the given nesting level of the current thread. For values of level outside zero to omp_get_level -1 is returned; if level is omp_get_level the result is identical to omp_get_thread_num.
// So be careful!

#include <stdio.h>
#include <omp.h>

int main() {
    // Set the number of threads for the outer and inner parallel regions
    int outer_threads = 2;
    int inner_threads = 4;

    // Enable nested parallelism
    omp_set_nested(1);

    // Outer parallel region
    #pragma omp parallel num_threads(outer_threads)
    {
        int outer_thread_id = omp_get_thread_num();
        printf("Outer thread %d (Level %d)\n", outer_thread_id, omp_get_level()-1);

        // Inner parallel region
        #pragma omp parallel num_threads(inner_threads)
        {
            int inner_thread_id = omp_get_thread_num();
            printf("Inner thread %d (Level %d, Active Level %d, Team Size %d, Ancestor Thread %d)\n",
                   inner_thread_id, omp_get_level()-1, omp_get_active_level(),
                   omp_get_team_size(omp_get_level()), omp_get_ancestor_thread_num(omp_get_level()-1));
        }
    }

    return 0;
}

