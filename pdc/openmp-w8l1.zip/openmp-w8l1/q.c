#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define HASH_SIZE 100
#define EMPTY -1
#define DELETED -2

typedef struct {
    int key;
    int value;
} Entry;

typedef struct {
    Entry table[HASH_SIZE];
    omp_lock_t locks[HASH_SIZE];
} HashTable;

// Initialize the hash table
void initHashTable(HashTable* ht) {
    for (int i = 0; i < HASH_SIZE; i++) {
        ht->table[i].key = EMPTY;
        omp_init_lock(&(ht->locks[i]));
    }
}

// Hash function
int hash(int key) {
    return key % HASH_SIZE;
}

// Insert key-value pair into hash table
void insert(HashTable* ht, int key, int value) {
    int index = hash(key);

    omp_set_lock(&(ht->locks[index])); // Acquire lock for this index

    // Linear probing for collision resolution
    while (ht->table[index].key != EMPTY && ht->table[index].key != DELETED) {
        index = (index + 1) % HASH_SIZE;
    }

    ht->table[index].key = key;
    ht->table[index].value = value;

    omp_unset_lock(&(ht->locks[index])); // Release lock for this index
}

// Search for a key in the hash table
int search(HashTable* ht, int key) {
    int index = hash(key);

    omp_set_lock(&(ht->locks[index])); // Acquire lock for this index

    // Linear probing for collision resolution
    while (ht->table[index].key != key && ht->table[index].key != EMPTY) {
        index = (index + 1) % HASH_SIZE;
    }

    int result = -1;
    if (ht->table[index].key == key) {
        result = ht->table[index].value;
    }

    omp_unset_lock(&(ht->locks[index])); // Release lock for this index

    return result;
}

// Clean up the hash table
void cleanupHashTable(HashTable* ht) {
    for (int i = 0; i < HASH_SIZE; i++) {
        omp_destroy_lock(&(ht->locks[i]));
    }
}

int main() {
    HashTable ht;
    initHashTable(&ht);

    // Insert some key-value pairs
    insert(&ht, 10, 100);
    insert(&ht, 20, 200);
    insert(&ht, 30, 300);

    // Search for keys
    printf("Value for key 10: %d\n", search(&ht, 10));
    printf("Value for key 20: %d\n", search(&ht, 20));
    printf("Value for key 30: %d\n", search(&ht, 30));
    printf("Value for key 40: %d\n", search(&ht, 40)); // Key not found

    cleanupHashTable(&ht);
    return 0;
}

