//Purpose: Learn about criticl sections
// For compilation; gcc -o n -Wall -fopenmp n.c

#include <stdio.h>
#include <omp.h>

int main() {
    int shared_counter = 0;
    int num_threads = 4;

    #pragma omp parallel num_threads(num_threads)
    {
        int tid = omp_get_thread_num();

        // Each thread increments the shared_counter
        #pragma omp critical
        {
            shared_counter++;
            printf("Thread %d incremented the counter. Current value: %d\n", tid, shared_counter);
        }
    }

    printf("Final counter value: %d\n", shared_counter);

    return 0;
}

