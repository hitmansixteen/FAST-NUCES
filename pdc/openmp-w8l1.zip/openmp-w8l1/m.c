// Purpose: Simple example to learn about barrier

#include <stdio.h>
#include <unistd.h>
#include <omp.h>

int main() {
    int tid;
    #pragma omp parallel private(tid)
    {
        tid = omp_get_thread_num();
        printf("Thread %d is doing some work\n", tid);
	if (tid == 0) sleep(5);

        // All threads wait here until all threads have reached this point
        #pragma omp barrier

        printf("Thread %d finished its work\n", tid);
    }

    return 0;
}

