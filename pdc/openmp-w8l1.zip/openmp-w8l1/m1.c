// Purpose: Simple example to learn about barrier deadlocks

#include <stdio.h>
#include <unistd.h>
#include <omp.h>

int main() {
    int tid;
    #pragma omp parallel private(tid)
    {
        tid = omp_get_thread_num();
        printf("Thread %d is doing some work\n", tid);
	// Don't do the following where not all threads come to barrier!
	if (tid != 0)
	{
        	#pragma omp barrier


	}

        printf("Thread %d finished its work\n", tid);
    }

    return 0;
}

