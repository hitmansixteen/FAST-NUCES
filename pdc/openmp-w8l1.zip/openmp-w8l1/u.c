#include <stdio.h>
#include <omp.h>

// Declare a threadprivate variable in global scope
int my_private_variable;
#pragma omp threadprivate(my_private_variable)

int main() {
    // Initialize the threadprivate variable in the master thread
    my_private_variable = omp_get_thread_num();

    // Parallel region with two threads
    #pragma omp parallel num_threads(2)
    {
        // Each thread will have its own copy of my_private_variable
        printf("Thread %d: my_private_variable = %d\n", omp_get_thread_num(), my_private_variable);
        
        // Modify the private variable within the parallel region
        my_private_variable += 1;

        // Print the modified value within the parallel region
        printf("Thread %d: modified my_private_variable = %d\n", omp_get_thread_num(), my_private_variable);
    }

    // Parallel region with two threads
    #pragma omp parallel num_threads(2)
    {
        // Each thread will have its own copy of my_private_variable
        printf("Thread %d: my_private_variable = %d\n", omp_get_thread_num(), my_private_variable);

        // Modify the private variable within the parallel region
        my_private_variable += 1;

        // Print the modified value within the parallel region
        printf("Thread %d: modified my_private_variable = %d\n", omp_get_thread_num(), my_private_variable);
    }


    return 0;
}

