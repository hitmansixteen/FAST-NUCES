#include <stdio.h>
#include <omp.h>

int main() {
    int shared_variable = 0;

    #pragma omp parallel num_threads(4)
    {
        int tid = omp_get_thread_num();

        // Increment shared_variable atomically
        #pragma omp atomic
        shared_variable++;

        printf("Thread %d: shared_variable = %d\n", tid, shared_variable);
    }

    printf("Final shared_variable value: %d\n", shared_variable);

    return 0;
}

