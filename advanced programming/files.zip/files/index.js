import Head from "next/head";
import Image from "next/image";
import localFont from "next/font/local";
import styles from "@/styles/Home.module.css";
import Link from "next/link";
import fs from 'fs/promises';
import path from 'path';

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

function Home(props) {
  return (
      <div>
        <h1>Home Page</h1>
        <ul>
          {props.products.map(e=>{
            return <li key={e.id}>{e.title}</li>
          })}
        </ul>
        
      </div>
    
  );
}

export async function getStaticProps(){
  //running server-side code & using the FileSystem module of Node server
  const p=path.join(process.cwd(),'data','dummy-backend.json');
  const datajson =await fs.readFile(p);
  const data=JSON.parse(datajson);
  console.log("re-rendering it")
  return{
    props:{
        products:data.products
    },
    //Incremental Static Regeneration
    revalidate:60
  }
}

export default Home;