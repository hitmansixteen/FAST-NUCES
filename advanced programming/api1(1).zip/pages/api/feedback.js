import fs from 'fs';  
import path from 'path';  

function handler(req, res) {
   
  // Check if the request method is POST, indicating a form submission.
  if (req.method === 'POST') {
    const e = req.body.email;  // Extract the email from the request body.
    const f = req.body.feedback;  // Extract the feedback from the request body.

    const p = path.join(process.cwd(), 'data', 'feedback.json');
    
    // Read the contents of the 'feedback.json' file.
    const fileData = fs.readFileSync(p);
    
    // Parse the file data (assumed to be in JSON format) into a JavaScript array.
    const arr = JSON.parse(fileData);

    // Create a new feedback object with a unique `id`, the user's email, and feedback.
    const newFeedback = {
      id: new Date().toISOString(),  // Generate a unique ID based on the current timestamp.
      email: e,  
      feedback: f  
    };

    // Add the new feedback object to the array of feedbacks.
    arr.push(newFeedback);
    
    // Write the updated array back to the 'feedback.json' file.
    fs.writeFileSync(p, JSON.stringify(arr));

    // Send a response with status 201 (Created) and a message.
    res.status(201).json({ message: "stored in file" });
  }
  else {
    // If the request method is not POST, send a 200 status and a success message.
    res.status(200).json({ message: "successful" });
  }
}

export default handler;  
