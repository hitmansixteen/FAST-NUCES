import Head from "next/head";
import Image from "next/image";
import localFont from "next/font/local";
import styles from "@/styles/Home.module.css";
import { useRef } from "react";
const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function Home() {
  const e = useRef();  // Declare a ref object `e` to store a reference to the email input field.
  const f = useRef();  // Declare another ref object `f` to store a reference to the feedback textarea.

  function submitIt(event) {
    event.preventDefault();  // Prevents the default form submission behavior (i.e., page reload).

    const enteredEmail = e.current.value;  // Get the value entered in the email input field using the ref `e`.
    const enteredFeedback = f.current.value;  // Get the value entered in the feedback textarea using the ref `f`.

    // Make a POST request to the `/api/feedback` API route with the email and feedback data.
    fetch('/api/feedback', {
      method: 'POST',  // Use the POST method to send data to the server.
      body: JSON.stringify({
        email: enteredEmail,  
        feedback: enteredFeedback  
      }),
      headers: {
        'Content-Type': 'application/json'  // Specify the request body format as JSON.
      }
    })
    .then(res => res.json())  // Convert the response from the server into a JSON object.
    .then(data => console.log(data));  // Log the response from the server to the console.
  }
  return (
    <div>
      <h1>Home Page</h1>
      
      <form>
      <div>
        <label htmlFor='email'>Your email</label>
        <input type='email' id='email' ref={e}/>
      </div>
      <div>
        <label htmlFor='feedback'>Your feedback</label>
        <textarea id='feedback' rows='5' ref={f}></textarea>
      </div>
      <button onClick={submitIt}>Send Feedback</button>
      </form>
    </div>
  );
}








