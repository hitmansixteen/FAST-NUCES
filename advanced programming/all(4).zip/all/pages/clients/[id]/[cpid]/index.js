import { useRouter } from "next/router";

export default function ClientsPorject() {
    const r=useRouter()
    console.log(r.query)
    return (
        <div>
          <h1>Specific Project named {r.query.cpid} of Specific Client named {r.query.id}</h1>
        </div>
      
    );
  }