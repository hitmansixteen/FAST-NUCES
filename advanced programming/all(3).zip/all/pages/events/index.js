export default function AllEventsPage() {
    return (
        <div>
          <h1>All Event Page</h1>
        </div>
      
    );
  }