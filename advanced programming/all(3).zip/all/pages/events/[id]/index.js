export default function DetailedEventPage() {
    return (
        <div>
          <h1>Detailed Event Page</h1>
        </div>
      
    );
  }