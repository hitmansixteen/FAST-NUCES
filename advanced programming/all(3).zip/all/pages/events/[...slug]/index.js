export default function FilteredEventsPage() {
    return (
        <div>
          <h1>Filtered Events Page</h1>

        </div>
      
    );
  }