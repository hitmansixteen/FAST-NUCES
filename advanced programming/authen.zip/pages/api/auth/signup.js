import { MongoClient } from "mongodb";

export default async function handler(req, res) {
    if(req.method==='POST')
    {

    
    const data=req.body;
    const email=data.email;
    const pass=data.password;
    const client= await MongoClient.connect("")
    const db= client.db();


    db.collection("users").insertOne({
        email:email,
        password:pass
    })
    res.status(200).json({ message:"created user" });
  }
}
  