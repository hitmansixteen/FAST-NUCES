import AuthForm from '@/components/auth/auth-form';


function AuthPage() {
  return <AuthForm />;
}

export default AuthPage;