import { MongoClient } from "mongodb";


export default async function handler(req, res) {
    if(req.method==='POST')
    {
    
   
    const email=req.body.email;
    const pass=req.body.password;
    console.log(email,pass);
    const client=await MongoClient.connect("mongodb+srv://hira:123456.@cluster0.k927h.mongodb.net/coll?retryWrites=true&w=majority&appName=Cluster0")
    const db=client.db();


    db.collection("users").insertOne({
        email:email,
        password:pass
    })
    res.status(200).json({ message:"created user" });
  }
}
  