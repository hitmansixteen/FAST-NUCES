import CredentialsProvider from 'next-auth/providers/credentials';
import NextAuth from 'next-auth';
import { MongoClient } from 'mongodb';

export default NextAuth({
    session:{jwt:true},
    providers:[
        CredentialsProvider({
            name:'credentials',
            async authorize(cred){
                const client=await MongoClient.connect("mongodb+srv://hira:123456.@cluster0.k927h.mongodb.net/coll?retryWrites=true&w=majority&appName=Cluster0")
                const db=client.db();
                const user= await db.collection("users").findOne({email:cred.email})
                if(!user)
                {
                    throw new Error('no user found');
                }
                else{
                    if(cred.password === user.password)
                    {
                        return {email:user.email}
                    }
                    else
                    {
                        throw new Error('wrong password');
                    }
                }
            }
        })
    ]
})