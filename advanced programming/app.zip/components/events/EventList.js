import Event from "./Event";
import styles from './EventList.module.css';

export default function EventList(props) {
    return (
        <div>
          <ul className={styles.list}>
            {props.list.map(event=>{
               return <Event id={event.id} t={event.title} i={event.image} d={event.date} loc={event.location}/>
            })}
          </ul>
        </div>
      
    );
  }