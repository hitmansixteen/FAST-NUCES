import Head from "next/head";
import Image from "next/image";
import localFont from "next/font/local";
import styles from "@/styles/Home.module.css";
import { getFeaturedEvents } from "@/dummy-data";
import EventList from "@/components/events/EventList";


const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function FeaturedEventsPage() {
  const arr=getFeaturedEvents();
  console.log(arr)
  return (
    
      <div style={{textAlign:"center",fontFamily:"cursive"}}>
        <h1>Home Page: All Featured Events</h1> 
        <EventList list={arr}/>
      </div>
    
  );
}