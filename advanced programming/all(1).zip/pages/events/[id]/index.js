import EventContent from "@/components/event-detail/event-content";
import EventLogistics from "@/components/event-detail/event-logistics";
import EventSummary from "@/components/event-detail/event-summary";
import { getEventById } from "@/dummy-data";
import { useRouter } from "next/router";

export default function DetailedEventPage() {
    const r=useRouter();
    const event=getEventById(r.query.id);
    if(!event)
    {
      return <p>Event doesn't exists</p>
    }
    return (
      
        <div style={{textAlign:"center", fontFamily:"cursive"}}>
          <h1>Event Detail Page</h1> 
          <EventSummary title={event.title}/>
          <EventLogistics t={event.title} d={event.date} ad={event.location} i={event.image}/>
          <EventContent><p>{event.description}</p></EventContent>
        </div>
      
    );
  }