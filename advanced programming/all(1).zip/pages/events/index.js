import EventList from "@/components/events/EventList";
import EventSearch from "@/components/events/EventSearch";
import { getAllEvents } from "@/dummy-data";



export default function AllEventsPage() {
    const arr=getAllEvents();
    return (
      
        <div>
          <h1>All Events Page</h1>
          <EventSearch/>
          <EventList list={arr}/> 
        </div>
      
    );
  }