import EventList from "@/components/events/EventList";
import { getFilteredEvents } from "@/dummy-data";
import { useRouter } from "next/router";


export default function FilteredEventsPage() {
  const r=useRouter();
  const data=r.query.slug;
  console.log(data)
  const year=Number(data[0]);
  const month=Number(data[1]);
  if(isNaN(year)|| isNaN(month))
  {
    return <p>Invalid year or month</p>
  }
  const arr=getFilteredEvents({year:year,month:month})
  if(!arr||arr.length===0)
  {
    return <p>Event not Found</p>
  }
    return (
      
        <div>
          <h1>Filtered Events Page</h1> 
          <EventList list={arr}/>
        </div>
      
    );
  }