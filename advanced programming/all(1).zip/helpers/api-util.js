export async function getAllEvents(){
    return fetch('https://aslam-aa561-default-rtdb.firebaseio.com/events.json').then(res=>res.json()).then(data=>{
        const events=[]
        for(const key in data)
        {
            events.push({
                id:key,
                ...data[key]
            })
        }
        return events
    })
}

export async function getFeaturedEvents(){
    const arr=await getAllEvents()
    return arr.filter((event) => event.isFeatured);

}