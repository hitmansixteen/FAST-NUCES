function UserProfile(props){
    return (
        <div>
            <h1>{props.name}</h1>
        </div>
    )
}

export async function getServerSideProps(context){

    return{
        props:{
            name:context.params.uid
        }
    }
}
export default UserProfile;