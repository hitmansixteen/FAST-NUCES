export default function ErrorPage(){
    return(
        <div>Cant fetch</div>
    )
}