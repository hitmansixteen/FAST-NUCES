import path from 'path';
import fs from 'fs/promises';

function ProductDetailPage(props){
    //write this if condition when you set fallback to 'true'! Recall its purpose :)
    if(!props.loadedProduct)
    {
        return <p>Loading...</p>
    }

    return(
        <div>
            <h1>{props.loadedProduct.title}</h1>
            <p>{props.loadedProduct.des}</p>
        </div>
    )
}

export async function getStaticProps(context){
    const p=path.join(process.cwd(),'data','dummy-backend.json');
    const datajson =await fs.readFile(p);
    const data=JSON.parse(datajson);
    const p1=data.products.find(o=>o.id===context.params.pid)
    //there is no such product (it means you have given wrong pid in URL)
    if(!p1)
    {
        return{
            redirect:{
                destination:'/no-data'
            }
        }
    }
    
    return {
        props:{
            loadedProduct:p1
        }
    }
}
//define all paths in this func for which you want your server to pre-generate this dynamic page. It will then pre-generate all such pages during build time
export async function getStaticPaths(){
    const p=path.join(process.cwd(),'data','dummy-backend.json');
    const datajson =await fs.readFile(p);
    const data=JSON.parse(datajson);
    const ids=data.products.map(o=>o.id)
    const pathss=ids.map(o=>({params:{pid:o}}))
    return{
        paths:pathss,
        fallback:true
        //fallback:'blocking'
        //fallback: false  //it will make sure that only mentioned paths will be valid. For all other 'pid',it will be redirected to 404 page
    }
}
export default ProductDetailPage;