import './BuildControl.css'

const BuildControl=(props)=>{
    return(
        <div className='BuildControl'>
            <label className='Label'>{props.label}</label>
            <button className='Less' disabled={props.f} onClick={props.remove}>Less</button>
            <button className='More' onClick={props.add}>More</button>
        </div>
    )
}
export default BuildControl;