import BuildControl from './BuildControl/BuildControl'
import './BuildControls.css'
const BuildControls=(props)=>{
    return(
        <div className='BuildControls'>
            <p>Total Price: {props.tp}</p>
            {props.ing.map(obj=>{
                let flag=false
                if(obj.no<=0)
                {
                    flag=true
                }
                console.log(flag)
                return <BuildControl f={flag} remove={()=>props.removing(obj.name)} add={()=>props.adding(obj.name)}label={obj.name}/>
            })
            }
            <button className="OrderButton" onClick={props.order}>Order Now</button>
        </div>
    )
}

export default BuildControls