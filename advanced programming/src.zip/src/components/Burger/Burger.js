import BurgerIngredients from "./BurgerIngredients/BurgerIngredients";
import './Burger.css'
const Burger=(props)=>{

    let dynamic=props.ing.map(obj=>{
        let arr=[]
        for(let i=0;i<obj.no;i++)
        {
             arr.push(<BurgerIngredients type={obj.name}/>)
        }
        return arr
    })

    let flag=0
    for(let i of props.ing)
    {
        if(i.no!==0)
        {
            flag=1
        }
    }
    if(flag===0)
    {
        dynamic=<p>Please start adding ingredients</p>
    }
    return(
        <div className="Burger">
            <BurgerIngredients type="bread-top"/>
            {dynamic}
            <BurgerIngredients type="bread-bottom"/>
            
        </div>
    )
}
export default Burger;