import { useState } from "react";
import Burger from "../components/Burger/Burger";
import BuildControls from "../components/Burger/BuildControls/BuildControls";
import Summary from "../components/Summary/Summary";


const BurgerBuilder=()=>{
    let arr=[
        {name:"meat",no:0,price:55},
        {name:"cheese",no:0,price:44},
        {name:"salad",no:0,price:50},
    ]
  let [ing,setIng]=  useState(arr);
  let [totalPrice,setTotalPrice]=useState(0);
  let [flag,setFlag]=useState(false)

  let addIng=(n)=>{
    let arr=[...ing]
    let index=arr.findIndex(i=>i.name===n)
    arr[index].no+=1
    setIng(arr)
    let tp=totalPrice
    tp+=arr[index].price
    setTotalPrice(tp)
  }

  let removeIng=(n)=>{
    let arr=[...ing]
    let index=arr.findIndex(i=>i.name===n)
    arr[index].no-=1
    setIng(arr)
    let tp=totalPrice
    tp-=arr[index].price
    setTotalPrice(tp)
  }
  let letsOrder=()=>{
    setFlag(true)
  }
   return(
    <div>
        <Burger ing={ing}/>
        {flag===true &&<Summary ing={ing}/>}
        <BuildControls order={letsOrder} tp={totalPrice} ing={ing} adding={addIng} removing={removeIng}/>
    </div>
   ) 
}

export default BurgerBuilder;