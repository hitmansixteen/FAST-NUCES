import { useState } from "react";
import Burger from "../components/Burger/Burger";

const BurgerBuilder=()=>{
    let arr=[
        {name:'meat',no:3,price:44},
        {name:'cheese',no:1,price:20},
        {name:'salad',no:2,price:5}
    ]
    let [ingredients,setIng] =useState(arr)
   return(
    <div>
        <Burger ing={ingredients}/>
    </div>
   )
}

export default BurgerBuilder;