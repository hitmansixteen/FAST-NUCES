import BurgerIngredients from "./BurgerIngredients/BurgerIngredients";
import './Burger.css'
const Burger=(props)=>{
    let dynamic=props.ing.map(obj=>{
        let arr=[]
        for(let i=0;i<obj.no;i++)
        {
            arr.push(<BurgerIngredients type={obj.name}/>)
        }
        return arr
    })
    return(
        <div className="Burger">
          <BurgerIngredients type="bread-top"/>
            {dynamic}
          <BurgerIngredients type="bread-bottom"/>
            <p>Controls</p>
        </div>
    )
} 
export default Burger;