

const Layout=(props)=>{
    return(
        <div>
            <p>Toolbar</p>
            {props.children}
        </div>
    )
}
export default Layout;