export default function ShowBlogs() {
    return (
        <div>
          <h1>Show Blogs Page</h1>
        </div>
      
    );
  }