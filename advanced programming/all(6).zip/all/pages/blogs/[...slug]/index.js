import { useRouter } from "next/router";

export default function FilteredBlogs() {
    const r=useRouter()
    console.log(r.query)
    return (
        <div>
          <h1>Filtered Blogs Page</h1>
        </div>
      
    );
  }