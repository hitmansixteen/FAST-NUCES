import Head from "next/head";
import Image from "next/image";
import localFont from "next/font/local";
import styles from "@/styles/Home.module.css";
import { useRef,useState } from "react";
const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function Home() {
  const [feedBackArr,setFeedBackArr]=useState([])
  const e=useRef();
  const f=useRef();
  function submission(event){
    event.preventDefault();
    const enteredEmail=e.current.value
    const enteredFeedback=f.current.value
    fetch('/api/feedback',{
      method:'POST',
      body:JSON.stringify({
        email:enteredEmail,
        feedback:enteredFeedback
      }),
      headers:{
        'Content-Type':'application/json'
      }
    }).then(res=>res.json()).then(data=>console.log(data))
  }

  function load(){
    //get data from api
    fetch('/api/feedback').then(res=>res.json()).then(data=>setFeedBackArr(data.feedback))
  }
  return (
    <div>
      <h1>Home Page</h1>
      <form>
      <div>
        <label htmlFor='email'>Your email</label>
        <input type='email' id='email' ref={e} />
      </div>
      <div>
        <label htmlFor='feedback'>Your feedback</label>
        <textarea id='feedback' rows='5' ref={f} ></textarea>
      </div>
      <button onClick={submission}>Send Feedback</button>
      </form>
      <button onClick={load}>Load Feedback</button>
      <ul>
        {feedBackArr.map(i=><li>{i.feedback}</li>)}
      </ul>
    </div>
  );
}











