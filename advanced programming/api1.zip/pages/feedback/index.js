import fs from 'fs';
import path from 'path';
import {useState} from 'react';

function FeedbackPage(props){

    const [feedbackItem,setFeedbackItem]=useState()
    function showFeedback(id)
    {
        fetch('/api/'+id).then(res=>res.json()).then(data=>setFeedbackItem(data.feedbackObj))
    }
    return(
        <div>
            {feedbackItem && <p>{feedbackItem.email}</p>}
            <ul>
                 {props.f.map(i=><li>{i.feedback}<button onClick={()=>showFeedback(i.id)}>Show Details</button></li>)}
            </ul>
        </div>
        
    )
}
export async function getStaticProps(){
    const p=path.join(process.cwd(),'data','dummy-data.json')
    const fileData=fs.readFileSync(p)
    const arr=JSON.parse(fileData)
        return {
            props:{
                f:arr
            }
        }
}

export default FeedbackPage;