import fs from 'fs';
import path from 'path';

function handler(req,res){
    const id=req.query.feedbackID
    const p=path.join(process.cwd(),'data','dummy-data.json')
    const fileData=fs.readFileSync(p)
    const arr=JSON.parse(fileData)
    const feedback=arr.find(f=>f.id===id)
    res.status(200).json({feedbackObj:feedback})
}

export default handler;