import fs from 'fs'
import path from 'path'

function handler(req,res)
{
    if(req.method==='POST')
    {
        const email=req.body.email
        const feedback=req.body.feedback
        const p=path.join(process.cwd(),'data','dummy-data.json')
        const fileData=fs.readFileSync(p)
        const arr=JSON.parse(fileData)
        arr.push({
            id:new Date().toISOString(),
            email:email,
            feedback:feedback
        })
        console.log("this is it")
        fs.writeFileSync(p,JSON.stringify(arr))
        res.status(201).json({message:"Stored in file"})
    }
    else{
        //send response back to client
        const p=path.join(process.cwd(),'data','dummy-data.json')
        const fileData=fs.readFileSync(p)
        const arr=JSON.parse(fileData)
        res.status(200).json({feedback:arr})
    }
}
export default handler;