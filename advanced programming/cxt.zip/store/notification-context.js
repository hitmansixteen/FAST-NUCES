import { createContext } from "react";
import { useState } from "react";

const NotificationContext = createContext({
    notification:null,   //{title,msg,status}
    showNotification:function(data){},
    hideNotification:function(){}
})

export function NotificationContextProvider(props){

    const [activeNotification,setActiveNotification]=useState()
    function showNotHandler(data){
        setActiveNotification(data)
    }

    function hideNotHandler(){
        setActiveNotification(null)
    }

    const context={notification:activeNotification,showNotification:showNotHandler,hideNotification:hideNotHandler}
    return(
        <NotificationContext.Provider value={context}>
            {props.children}
        </NotificationContext.Provider>
    )
}

export default NotificationContext;












































// const NotificationContext=createContext({notification:null, //{title,message,status}
//                                 showNotification:function(data){},
//                                 hideNotification:function(){}
//                                 });

// export function NotificationContextProvider(props){
//     const[activeNotification,setActiveNotification]=useState()
//     function showNotificationHandler(data){
//         setActiveNotification(
//             // {
//             // title:data.title,
//             // message:data.message,
//             // status:data.status
//             // }
//             data
//     )}

//     function hideNotificationHandler(){
//         setActiveNotification(null)
//     }
//     const context={notification:activeNotification,showNotification:showNotificationHandler,hideNotification:hideNotificationHandler}
//     return(
//         <NotificationContext.Provider value={context}>
//             {props.children}
//         </NotificationContext.Provider>
//     )
// }



// export default NotificationContext;