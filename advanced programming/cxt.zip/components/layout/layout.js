
import { useContext } from "react";
import Header from "./main-header";
import NotificationContext from "@/store/notification-context";
import Notification from "../notification/notification";


export default function Layout(props){
    const ctx=useContext(NotificationContext)
    const active=ctx.notification
    return(
        <>
        <Header/>
        <main>
            {props.children}
        </main>
        {active && <Notification title={active.title} message={active.message} status={active.status}/>}
         </>
    )
}