import classes from './newsletter-registration.module.css';
import {  useRef,useContext } from 'react';
import NotificationContext from '@/store/notification-context';

function NewsletterRegistration() {
  const emailInputRef = useRef();
  const ctx=useContext(NotificationContext)

  function registrationHandler(event) {
    event.preventDefault();
    const enteredEmail = emailInputRef.current.value;

    ctx.showNotification({
      title:"Signing up",
      message:"registering",
      status:"pending"
    })
    
    fetch('/api/newsletter', {
      method: 'POST',
      body: JSON.stringify({ email: enteredEmail }),
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((data) => ctx.showNotification({title:"Signed up", message:"Registered",status:"success" }));
  }
  

  return (
    <section className={classes.newsletter}>
      <h2>Sign up to stay updated!</h2>
      <form onSubmit={registrationHandler}>
        <div className={classes.control}>
          <input
            type='email'
            id='email'
            placeholder='Your email'
            aria-label='Your email'
            ref={emailInputRef}
          />
          <button>Register</button>
        </div>
      </form>
    </section>
  );
}

export default NewsletterRegistration;