

export default function handler(req, res) {
  if (req.method === 'POST') {
    const userEmail = req.body.email;
    mongodb+srv://hira:12345.@cluster0.gm1ug.mongodb.net/newsletter?retryWrites=true&w=majority&appName=Cluster0
    res.status(200).json({ message: "Signed Up!", msg:userEmail});
  }
}
