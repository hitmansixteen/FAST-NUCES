import PersonsList from "@/components/PersonsList";

const AboutPage=()=>{
    return(
        <div>
            About page
        </div>
    )
}
export default AboutPage;