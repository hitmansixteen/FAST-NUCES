const ProductsPage=()=>{
    return(
        <div>
           Products page
        </div>
    )
}
export default ProductsPage;