import { useRouter } from "next/router";

const ProductDetail=()=>{
    const r=useRouter();
    console.log(r.query.id)
    return(
        <div>
            Detailed Product No {r.query.id} page
        </div>
    )
}
export default ProductDetail;