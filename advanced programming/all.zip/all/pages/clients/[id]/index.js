import { useRouter } from "next/router";

export default function DetailedClient() {
    const r=useRouter()
    console.log(r.query)


    return (
        <div>
          <h1>Show All projects of a Specific Client {r.query.id}</h1>
           
        </div>
      
    );
  }