import Link from "next/link";


export default function ClientsPage() {
    const arr=[
        {id:"hira",name:"Hira Butt"},
        {id:"ahmad",name:"Ahmad Khalil"}
    ]
    return (
        <div>
          <h1>Show all clients Page</h1>
          <ul>
           {arr.map(i=>{
            return <li><Link href={"/clients/"+i.id}>{i.name}</Link></li>
           })}
          </ul>
        </div>
      
    );
  }