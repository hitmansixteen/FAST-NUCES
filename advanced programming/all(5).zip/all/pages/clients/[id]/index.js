import { useRouter } from "next/router";

export default function DetailedClient() {
    const r=useRouter()
    console.log(r.query)
    const btnHndler=()=>{
	//load data
	r.push('/clients/'+r.query.id+'/proj1');
	}

    return (
        <div>
          <h1>Show All projects of a Specific Client {r.query.id}</h1>
	  <button onClick={btnHndler}>Load Project A</button>           
        </div>
      
    );
  }