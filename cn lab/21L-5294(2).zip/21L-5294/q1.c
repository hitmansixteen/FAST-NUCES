#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>

int isPalindrome(char *str){
	int start=0;
	int end = strlen(str)-1;
	
	if(strlen(str)==0)
		return 0;
	while(start<end){
		if(str[start]!=str[end])
			return 0;
		start++;
		end--;
	}
	return 1;
	
}

int main(){
	FILE *fp1 = fopen("input.txt","r");
	FILE *fp2 = fopen("output.txt","w");
	
	char buff[255];
	int total=0;
	int finalTotal=0;
	while(fgets(buff,255,(FILE*)fp1)){ 
		char buff2[255];
		strcpy(buff2,buff);
		char *token = strtok(buff," .\"\n");
		while(token!=NULL){
			int x = isPalindrome(token);
			if(x){
				printf("%s\n",token);
			}
			total+= x;
			token = strtok(NULL," .\"\n");
		}
		if(total){
			fprintf(fp2,"%s\n",buff2);
		}
		finalTotal+=total;
		total=0;
	}
	fprintf(fp2,"Total number of palindromes: %d\n",finalTotal);
	
	fclose(fp1);
	fclose(fp2);

	return 0;
}
