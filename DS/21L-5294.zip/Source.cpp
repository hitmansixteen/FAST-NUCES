#include<iostream>
using namespace std;

template<class T>
class SortedSet{
private:
	class node {
	public:
		T data;
		node* next;
	};
	node* head;
	node* tail;
	node* createNode(T val) {//create a node;
		node* temp = new node();
		temp->data = val;
		temp->next = NULL;
		return temp;
	}
public:
	SortedSet() { head = tail = NULL; }
	void insert(T const data) {
		if (head == NULL) {//add in an empty linkedlist
			head = createNode(data);
			print();
			return;
		}
		node *prev, *curr, *p;
		prev = curr = p = head;

		while (p) {// find if data already exists
			if (p->data == data) {
				cout << data << " Already Exists!\n";
				return;
			}
			p = p->next;
		}
		while (curr && curr->data < data) { //traverse to the place where the node will be inserted
			prev = curr;
			curr = curr->next;
		}
		node* temp = createNode(data);
		if (curr == head) {// inserting node at head
			temp->next = head;
			head = temp;
		}
		else {// inserting node in between and at end
		temp->next = curr;
		prev->next = temp;
		}

	}

	void Delete(int const index) {
		int k = index;
		if (k < 0) {// check out of bound
			cout << "Out of Bound!\n";
			return;
		}
		node* curr, * prev;
		curr = prev = head;
		while (k != 0 && curr != NULL) {
			prev = curr;
			curr = curr->next;
			k--;
		}
		if (k != 0 || curr == NULL) {//if index greater than length of linkedlist
			cout << "Out of Bound\n";
			return;
		}
		else if (curr == head) {//to delete head
			curr = curr->next;
			delete head;
			head = curr;
		}
		else {//to delete in between and at end
			prev->next = curr->next;
			delete curr;
		}
		cout << "Deleted!\n";
		print();
	}
	void print() {
		node* p = head;
		while (p) {
			cout << p->data << " ";
			p = p->next;
		}
		cout << endl;
	}
	void Union(SortedSet<T>const& otherSet)
	{
		node* curr1, * curr2, * prev1;
		curr1 = head, curr2 = otherSet.head, prev1 = head;
		if (curr1 == NULL) { // if the current set is empty;
			node* temp = createNode(curr2->data);
			temp->next = curr1;
			head = temp;
			prev1 = temp;
			curr2 = curr2->next;
			print();
		}	
		while (curr1!=NULL && curr2!=NULL)
		{
			if (curr1->data > curr2->data && curr1 == head) {// this will insert before head and change the head
				node* temp = createNode(curr2->data);
				temp->next = curr1;
				head = temp;
				prev1 = temp;
				curr2 = curr2->next;
				print();
			} 
			else if (curr1->data > curr2->data) {// add in between
				node* temp = createNode(curr2->data);
				temp->next = curr1;
				prev1->next = temp;
				prev1 = temp;
				curr2 = curr2->next;
				print();
			}
			else if (curr1->data < curr2->data) { //move forward
				prev1 = curr1;
				curr1 = curr1->next;
			}

			else if (curr2->data == curr1->data) {// skip same elements	
				cout << curr2->data << " Already Exists\n";
				curr2 = curr2->next;
			}										
		}
		while (curr2) {//add the remaining
			node* temp = createNode(curr2->data);
			temp->next = curr1;
			prev1->next = temp;
			prev1 = temp;
			curr2 = curr2->next;
			print();
		}
	}

	void rotate(int k) {
		node *p ,*q;
		q = p = head;
		int size = 1;
		while (p->next) {// to find size and get to the end
			size++;
			p = p->next;
		}
		p->next = head;// circularly linked list
		k = k % size;
		for (int i = 0; i < k; i++) {
			p = p->next;
			q = q->next;
		}
		head = q;
		p->next = NULL;
		print();

	}

	void reverse() {
		node* curr, * prev, *next;
		curr = head, prev = next = NULL;
		while (curr) {
			next = curr->next;
			curr->next = prev;
			prev = curr;
			curr = next;
		}
		head = prev;
		print();
	}
	
};

int main()
{
	system("cls");

	SortedSet<int> a;
	SortedSet<int> b;
	int size=0, data=0,input = 0;
	cout << "1. Input in linkedList\n";
	cout << "2. Delete an index in linkedList.\n";
	cout << "3. Reverse the linkedList\n";
	cout << "4. Rotate the linkedList Counter-Clockwise\n";
	cout << "5. Union of two linkList\n";
	cout << "-1 To exit.\n";
	while (input != -1) {
		cout << "Enter your choice: ";
		cin >> input;
		if (input == 1) {
			cout << "Enter size of the linkedList: ";
			cin >> size;
			cout << "Enter data: ";
			for (int i = 0; i < size; i++) {
				cin >> data;
				a.insert(data);
			}
			a.print();
		}
		else if (input == 2) {
			int index;
			cout << "Which index do you want to remove? ";
			cin >> index;
			a.Delete(index);
		}
		else if (input == 3) {
			cout << "Reversed.\n";
			a.reverse();
		}
		else if (input == 4) {
			int k;
			cout << "How many times? ";
			cin >> k;
			cout << "Rotated.\n";
			a.rotate(k);
		}
		else if (input == 5) {
			cout << "Enter size of the linkedList: ";
			cin >> size;
			cout << "Enter data: ";
			for (int i = 0; i < size; i++) {
				cin >> data;
				b.insert(data);
			}
			cout << "Union Taken.\n";
			a.Union(b);
		}
		else
			cout << "Invalid Input.\n";

	}

	return 0;
}